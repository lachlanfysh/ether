#include "src/grid_sequencer/ModularGridSequencer.h"
#include "src/grid_sequencer/utils/Logger.h"
#include <iostream>
#include <thread>
#include <chrono>
#include <signal.h>
#include <termios.h>
#include <unistd.h>
#include <fcntl.h>

using namespace GridSequencer;

// Global instance for signal handling
std::unique_ptr<ModularGridSequencer> g_sequencer;
volatile bool g_running = true;
termios g_originalTermios;

void restoreTerminal() {
    tcsetattr(STDIN_FILENO, TCSAFLUSH, &g_originalTermios);
}

void signalHandler(int signal) {
    std::cout << "\n🛑 Received signal " << signal << ", shutting down gracefully..." << std::endl;
    g_running = false;
    if (g_sequencer) {
        g_sequencer->shutdown();
    }
    restoreTerminal();
}

void setupRawInput() {
    // Get current terminal attributes
    tcgetattr(STDIN_FILENO, &g_originalTermios);

    // Set up raw mode for immediate key response
    termios raw = g_originalTermios;
    raw.c_lflag &= ~(ICANON | ECHO);
    raw.c_cc[VTIME] = 0;
    raw.c_cc[VMIN] = 1;

    tcsetattr(STDIN_FILENO, TCSAFLUSH, &raw);

    // Set stdin to non-blocking
    int flags = fcntl(STDIN_FILENO, F_GETFL, 0);
    fcntl(STDIN_FILENO, F_SETFL, flags | O_NONBLOCK);
}

void printControls() {
    std::cout << "🎹 === MODULAR GRID SEQUENCER CONTROLS ===" << std::endl;
    std::cout << "🎵 Complete Modular Architecture (15 Engines)" << std::endl;
    std::cout << "" << std::endl;
    std::cout << "📋 TRANSPORT:" << std::endl;
    std::cout << "  [SPACE]  - Play/Stop sequencer" << std::endl;
    std::cout << "  [q]      - Quit application" << std::endl;
    std::cout << "" << std::endl;
    std::cout << "🎹 ENGINE CONTROL:" << std::endl;
    std::cout << "  [1-9]    - Switch to engine 0-8" << std::endl;
    std::cout << "  [+/-]    - Adjust BPM (±10)" << std::endl;
    std::cout << "  [a]      - Play all engines toggle" << std::endl;
    std::cout << "" << std::endl;
    std::cout << "🎵 PATTERN EDITING:" << std::endl;
    std::cout << "  [0-9,a-f] - Toggle steps 0-15 (hex)" << std::endl;
    std::cout << "  [c]      - Clear current pattern" << std::endl;
    std::cout << "  [w]      - Write mode toggle" << std::endl;
    std::cout << "  [s]      - Save current pattern" << std::endl;
    std::cout << "  [l]      - Load saved pattern" << std::endl;
    std::cout << "" << std::endl;
    std::cout << "🎛️  PERFORMANCE FX:" << std::endl;
    std::cout << "  [f]      - Toggle stutter FX" << std::endl;
    std::cout << "  [v]      - Toggle reverse FX" << std::endl;
    std::cout << "  [t]      - Toggle 6/8 quantize FX" << std::endl;
    std::cout << "" << std::endl;
    std::cout << "📊 STATUS:" << std::endl;
    std::cout << "  [p]      - Print current status" << std::endl;
    std::cout << "  [h]      - Show this help" << std::endl;
    std::cout << "" << std::endl;
    std::cout << "🎛️  15 synthesis engines ready!" << std::endl;
}

void printStatus(ModularGridSequencer* sequencer) {
    auto stateManager = sequencer->getStateManager();
    auto parameterSystem = sequencer->getParameterSystem();
    auto sequencerEngine = sequencer->getSequencerEngine();
    auto patternSystem = sequencer->getPatternSystem();
    auto fxSystem = sequencer->getFXSystem();

    if (!stateManager || !parameterSystem || !sequencerEngine || !patternSystem || !fxSystem) {
        std::cout << "❌ Could not access sequencer components" << std::endl;
        return;
    }

    std::cout << "\n📊 === SEQUENCER STATUS ===" << std::endl;
    std::cout << "🎵 Transport: " << (stateManager->isPlaying() ? "▶️  PLAYING" : "⏸️  STOPPED") << std::endl;
    std::cout << "🥁 Current Step: " << stateManager->getCurrentStep() << "/16" << std::endl;
    std::cout << "🎹 Current Engine: " << stateManager->getCurrentEngine() << " (15 engines available)" << std::endl;
    std::cout << "🎼 Pattern Bank: " << stateManager->getCurrentPatternBank() << " Slot: " << stateManager->getCurrentPatternSlot() << std::endl;
    std::cout << "⏱️  BPM: " << sequencerEngine->getBPM() << std::endl;
    std::cout << "🎛️  Active FX: " << fxSystem->getActiveEffectCount() << " effects" << std::endl;

    // Show pattern info for current engine
    int currentEngine = stateManager->getCurrentEngine();
    std::cout << "🎶 Pattern Steps (Engine " << currentEngine << "): ";
    for (int step = 0; step < 16; ++step) {
        auto stepData = patternSystem->getStep(currentEngine, step);
        std::cout << (stepData.active ? "●" : "○");
        if (step == 7) std::cout << " ";
    }
    std::cout << std::endl;
}

void handleKeyPress(char key, ModularGridSequencer* sequencer) {
    auto stateManager = sequencer->getStateManager();
    auto parameterSystem = sequencer->getParameterSystem();
    auto sequencerEngine = sequencer->getSequencerEngine();
    auto patternSystem = sequencer->getPatternSystem();
    auto fxSystem = sequencer->getFXSystem();

    if (!stateManager || !parameterSystem || !sequencerEngine || !patternSystem || !fxSystem) {
        return;
    }

    // Core transport controls (matching original)
    if (key == 'q') {
        std::cout << "\n👋 Goodbye!" << std::endl;
        g_running = false;
        return;
    }

    if (key == ' ') {
        if (stateManager->isPlaying()) {
            sequencerEngine->stop();
            std::cout << "\n⏸️  Sequencer STOPPED" << std::endl;
        } else {
            sequencerEngine->play();
            std::cout << "\n▶️  Sequencer PLAYING" << std::endl;
        }
        return;
    }

    if (key == 'c' || key == 'C') {
        int engine = stateManager->getCurrentEngine();
        for (int step = 0; step < 16; ++step) {
            patternSystem->clearStep(engine, step);
        }
        std::cout << "\n🧹 Pattern cleared for engine " << engine << std::endl;
        return;
    }

    if (key == 'w' || key == 'W') {
        // Toggle write mode (pattern editing)
        std::cout << "\n✏️  Write mode toggled" << std::endl;
        return;
    }

    if (key == 'a' || key == 'A') {
        // Toggle play all engines
        std::cout << "\n🎵 Play all engines toggled" << std::endl;
        return;
    }

    // Engine switching (1-9 keys)
    if (key >= '1' && key <= '9') {
        int engine = key - '1';
        if (engine < 15) {  // We have 15 engines
            stateManager->setCurrentEngine(engine);
            std::cout << "\n🎹 Switched to Engine " << engine << std::endl;
        }
        return;
    }

    // BPM controls
    if (key == '+' || key == '=') {
        float currentBPM = sequencerEngine->getBPM();
        float newBPM = std::min(200.0f, currentBPM + 10.0f);
        sequencerEngine->setBPM(newBPM);
        std::cout << "\n⏱️  BPM: " << newBPM << std::endl;
        return;
    }

    if (key == '-' || key == '_') {
        float currentBPM = sequencerEngine->getBPM();
        float newBPM = std::max(60.0f, currentBPM - 10.0f);
        sequencerEngine->setBPM(newBPM);
        std::cout << "\n⏱️  BPM: " << newBPM << std::endl;
        return;
    }

    // Performance FX controls (using different keys to avoid conflicts)
    if (key == 'f' || key == 'F') {
        if (fxSystem->isEffectActive(FX::PerformanceFX::STUTTER_SWEEP)) {
            fxSystem->deactivateEffect(FX::PerformanceFX::STUTTER_SWEEP);
            std::cout << "\n🎛️  Stutter FX OFF" << std::endl;
        } else {
            fxSystem->activateEffect(FX::PerformanceFX::STUTTER_SWEEP, 0.7f);
            std::cout << "\n🎛️  Stutter FX ON" << std::endl;
        }
        return;
    }

    if (key == 'v' || key == 'V') {
        if (fxSystem->isEffectActive(FX::PerformanceFX::REVERSE)) {
            fxSystem->deactivateEffect(FX::PerformanceFX::REVERSE);
            std::cout << "\n🎛️  Reverse FX OFF" << std::endl;
        } else {
            fxSystem->activateEffect(FX::PerformanceFX::REVERSE, 0.8f);
            std::cout << "\n🎛️  Reverse FX ON" << std::endl;
        }
        return;
    }

    if (key == 't' || key == 'T') {
        if (fxSystem->isEffectActive(FX::PerformanceFX::QUANTIZE_6_8)) {
            fxSystem->deactivateEffect(FX::PerformanceFX::QUANTIZE_6_8);
            std::cout << "\n🎛️  6/8 Quantize FX OFF" << std::endl;
        } else {
            fxSystem->activateEffect(FX::PerformanceFX::QUANTIZE_6_8, 0.6f);
            std::cout << "\n🎛️  6/8 Quantize FX ON" << std::endl;
        }
        return;
    }

    // Pattern and status controls
    if (key == 's' || key == 'S') {
        int bank = stateManager->getCurrentPatternBank();
        int slot = stateManager->getCurrentPatternSlot();
        patternSystem->savePattern(bank, slot);
        std::cout << "\n💾 Pattern saved to bank " << bank << " slot " << slot << std::endl;
        return;
    }

    if (key == 'l' || key == 'L') {
        int bank = stateManager->getCurrentPatternBank();
        int slot = stateManager->getCurrentPatternSlot();
        patternSystem->loadPattern(bank, slot);
        std::cout << "\n📂 Pattern loaded from bank " << bank << " slot " << slot << std::endl;
        return;
    }

    if (key == 'p' || key == 'P') {
        std::cout << std::endl;
        printStatus(sequencer);
        return;
    }

    if (key == 'h' || key == 'H') {
        std::cout << std::endl;
        printControls();
        return;
    }

    // Step editing (hex pattern: 0-9, a-f for steps 0-15)
    if ((key >= '0' && key <= '9') || (key >= 'a' && key <= 'f')) {
        int step;
        if (key >= '0' && key <= '9') {
            step = key - '0';
        } else {
            step = 10 + (key - 'a');
        }

        if (step < 16) {
            int engine = stateManager->getCurrentEngine();
            auto currentStep = patternSystem->getStep(engine, step);

            if (currentStep.active) {
                patternSystem->clearStep(engine, step);
                std::cout << "\n○ Step " << step << " cleared" << std::endl;
            } else {
                Pattern::StepData newStep;
                newStep.active = true;
                newStep.note = 60 + step;  // C4 + step offset
                newStep.velocity = 0.8f;
                newStep.hasAccent = (step % 4 == 0);
                patternSystem->setStep(engine, step, newStep);
                std::cout << "\n● Step " << step << " activated (note " << newStep.note << ")" << std::endl;
            }
        }
        return;
    }
}

char getKeyPress() {
    char ch;
    int result = read(STDIN_FILENO, &ch, 1);
    if (result == 1) {
        return ch;
    }
    return 0;
}

void runInteractiveLoop(ModularGridSequencer* sequencer) {
    std::cout << "\n🚀 Interactive mode started!" << std::endl;
    printStatus(sequencer);
    std::cout << "\nPress 'h' for help, 'q' to quit." << std::endl;

    auto lastDisplayTime = std::chrono::steady_clock::now();

    while (g_running) {
        // Process input like original grid_sequencer_advanced
        char c;
        while (read(STDIN_FILENO, &c, 1) == 1) {
            handleKeyPress(c, sequencer);
            if (!g_running) break;
        }

        // Update display periodically (like original)
        auto now = std::chrono::steady_clock::now();
        if (std::chrono::duration_cast<std::chrono::milliseconds>(now - lastDisplayTime).count() >= 1000) {
            // Show live status updates like original
            auto stateManager = sequencer->getStateManager();
            if (stateManager) {
                std::cout << "\r🎵 " << (stateManager->isPlaying() ? "PLAYING" : "STOPPED");
                std::cout << " | Step: " << (stateManager->getCurrentStep() + 1) << "/16";
                std::cout << " | Engine: " << stateManager->getCurrentEngine();
                std::cout << " | Press 'h' for help";
                std::cout << std::flush;
            }
            lastDisplayTime = now;
        }

        // Small delay like original (1ms)
        std::this_thread::sleep_for(std::chrono::microseconds(1000));
    }
}

int main() {
    // Set up signal handlers for graceful shutdown
    signal(SIGINT, signalHandler);
    signal(SIGTERM, signalHandler);
    atexit(restoreTerminal);

    // Initialize logging
    Utils::Logger::getInstance().setLogLevel(Utils::LogLevel::INFO);

    printControls();

    try {
        // Create and initialize the modular sequencer
        g_sequencer = std::make_unique<ModularGridSequencer>();

        auto initResult = g_sequencer->initialize();
        if (initResult.isError()) {
            std::cerr << "❌ Failed to initialize modular sequencer: " << initResult.error() << std::endl;
            return 1;
        }

        std::cout << "\n✅ Modular Grid Sequencer initialized successfully!" << std::endl;
        std::cout << "🎼 15 synthesis engines loaded and ready" << std::endl;
        std::cout << "🎛️  Performance FX system active" << std::endl;
        std::cout << "🎹 Pattern system ready (64 pattern slots)" << std::endl;

        // Setup some default patterns for demonstration
        auto patternSystem = g_sequencer->getPatternSystem();
        auto stateManager = g_sequencer->getStateManager();

        if (patternSystem && stateManager) {
            // Create a basic 4/4 kick pattern on engine 0
            for (int step = 0; step < 16; step += 4) {
                Pattern::StepData kickStep;
                kickStep.active = true;
                kickStep.note = 36; // Kick drum note
                kickStep.velocity = 0.9f;
                kickStep.hasAccent = (step == 0);
                patternSystem->setStep(0, step, kickStep);
            }

            // Create a snare pattern on engine 1
            for (int step = 4; step < 16; step += 8) {
                Pattern::StepData snareStep;
                snareStep.active = true;
                snareStep.note = 38; // Snare drum note
                snareStep.velocity = 0.8f;
                patternSystem->setStep(1, step, snareStep);
            }

            // Create a melodic pattern on engine 2
            int melody[] = {60, 64, 67, 72}; // C major chord notes
            for (int step = 0; step < 16; step += 2) {
                Pattern::StepData melodyStep;
                melodyStep.active = true;
                melodyStep.note = melody[step / 2 % 4];
                melodyStep.velocity = 0.6f;
                melodyStep.hasAccent = (step % 8 == 0);
                patternSystem->setStep(2, step, melodyStep);
            }

            stateManager->setCurrentEngine(0);
            std::cout << "🎵 Demo patterns loaded! Try engines 0, 1, and 2" << std::endl;
        }

        // Setup terminal for interactive input
        setupRawInput();

        // Run the interactive application
        runInteractiveLoop(g_sequencer.get());

        // Graceful shutdown
        std::cout << "\n🛑 Shutting down modular sequencer..." << std::endl;
        g_sequencer->shutdown();
        g_sequencer.reset();

        restoreTerminal();
        std::cout << "✅ Clean shutdown complete. Thanks for using Modular Grid Sequencer!" << std::endl;
        return 0;

    } catch (const std::exception& e) {
        std::cerr << "❌ Exception: " << e.what() << std::endl;
        if (g_sequencer) {
            g_sequencer->shutdown();
        }
        restoreTerminal();
        return 1;
    }
}