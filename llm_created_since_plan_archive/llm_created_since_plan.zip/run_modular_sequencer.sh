#!/bin/bash

echo "🎹 === MODULAR GRID SEQUENCER LAUNCHER ==="
echo "🚀 Starting your complete modular synthesizer..."
echo ""

# Check if the app exists
if [ ! -f "./modular_grid_sequencer" ]; then
    echo "❌ Application not found. Building first..."
    ./build_modular_app.sh
    echo ""
fi

echo "🎵 Launching Modular Grid Sequencer..."
echo "📋 Quick Controls:"
echo "   [SPACE] = Play/Stop"
echo "   [1-9]   = Switch engines"
echo "   [+/-]   = BPM ±10"
echo "   [f/r/t] = Toggle FX"
echo "   [p]     = Status"
echo "   [h]     = Help"
echo "   [q]     = Quit"
echo ""
echo "🎛️  15 synthesis engines ready!"
echo "⚡ Starting in 3 seconds..."
sleep 3

# Run the modular sequencer
./modular_grid_sequencer