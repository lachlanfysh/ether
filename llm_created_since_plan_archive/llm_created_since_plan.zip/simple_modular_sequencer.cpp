#include "src/grid_sequencer/ModularGridSequencer.h"
#include "src/grid_sequencer/utils/Logger.h"
#include <iostream>
#include <string>
#include <signal.h>

using namespace GridSequencer;

// Global instance for signal handling
std::unique_ptr<ModularGridSequencer> g_sequencer;
volatile bool g_running = true;

void signalHandler(int signal) {
    std::cout << "\n🛑 Received signal " << signal << ", shutting down gracefully..." << std::endl;
    g_running = false;
    if (g_sequencer) {
        g_sequencer->shutdown();
    }
}

void printHelp() {
    std::cout << "\n🎹 === MODULAR GRID SEQUENCER CONTROLS ===" << std::endl;
    std::cout << "Commands (press Enter after each):" << std::endl;
    std::cout << "  play     - Start/stop sequencer" << std::endl;
    std::cout << "  stop     - Stop sequencer" << std::endl;
    std::cout << "  engine N - Switch to engine N (0-8)" << std::endl;
    std::cout << "  bpm N    - Set BPM to N (60-200)" << std::endl;
    std::cout << "  step N   - Toggle step N (0-15)" << std::endl;
    std::cout << "  clear    - Clear current pattern" << std::endl;
    std::cout << "  save     - Save current pattern" << std::endl;
    std::cout << "  load     - Load saved pattern" << std::endl;
    std::cout << "  fx stutter - Toggle stutter FX" << std::endl;
    std::cout << "  fx reverse - Toggle reverse FX" << std::endl;
    std::cout << "  fx quantize - Toggle 6/8 quantize FX" << std::endl;
    std::cout << "  status   - Show current status" << std::endl;
    std::cout << "  help     - Show this help" << std::endl;
    std::cout << "  quit     - Exit application" << std::endl;
    std::cout << "🎛️  Example: 'engine 2', 'bpm 140', 'step 4', 'play'" << std::endl;
}

void printStatus(ModularGridSequencer* sequencer) {
    auto stateManager = sequencer->getStateManager();
    auto parameterSystem = sequencer->getParameterSystem();
    auto sequencerEngine = sequencer->getSequencerEngine();
    auto patternSystem = sequencer->getPatternSystem();
    auto fxSystem = sequencer->getFXSystem();

    if (!stateManager || !parameterSystem || !sequencerEngine || !patternSystem || !fxSystem) {
        std::cout << "❌ Could not access sequencer components" << std::endl;
        return;
    }

    std::cout << "\n📊 === SEQUENCER STATUS ===" << std::endl;
    std::cout << "🎵 Transport: " << (stateManager->isPlaying() ? "▶️  PLAYING" : "⏸️  STOPPED") << std::endl;
    std::cout << "🥁 Current Step: " << stateManager->getCurrentStep() << "/16" << std::endl;
    std::cout << "🎹 Current Engine: " << stateManager->getCurrentEngine() << " (15 engines available)" << std::endl;
    std::cout << "🎼 Pattern Bank: " << stateManager->getCurrentPatternBank() << " Slot: " << stateManager->getCurrentPatternSlot() << std::endl;
    std::cout << "⏱️  BPM: " << sequencerEngine->getBPM() << std::endl;
    std::cout << "🎛️  Active FX: " << fxSystem->getActiveEffectCount() << " effects" << std::endl;

    // Show pattern info for current engine
    int currentEngine = stateManager->getCurrentEngine();
    std::cout << "🎶 Pattern Steps (Engine " << currentEngine << "): ";
    for (int step = 0; step < 16; ++step) {
        auto stepData = patternSystem->getStep(currentEngine, step);
        std::cout << (stepData.active ? "●" : "○");
        if (step == 7) std::cout << " ";
    }
    std::cout << std::endl;
}

void processCommand(const std::string& command, ModularGridSequencer* sequencer) {
    auto stateManager = sequencer->getStateManager();
    auto parameterSystem = sequencer->getParameterSystem();
    auto sequencerEngine = sequencer->getSequencerEngine();
    auto patternSystem = sequencer->getPatternSystem();
    auto fxSystem = sequencer->getFXSystem();

    if (!stateManager || !parameterSystem || !sequencerEngine || !patternSystem || !fxSystem) {
        std::cout << "❌ Sequencer components not available" << std::endl;
        return;
    }

    if (command == "help") {
        printHelp();
    }
    else if (command == "quit" || command == "exit" || command == "q") {
        std::cout << "👋 Goodbye!" << std::endl;
        g_running = false;
    }
    else if (command == "play") {
        if (stateManager->isPlaying()) {
            sequencerEngine->stop();
            std::cout << "⏸️  Sequencer STOPPED" << std::endl;
        } else {
            sequencerEngine->play();
            std::cout << "▶️  Sequencer PLAYING" << std::endl;
        }
    }
    else if (command == "stop") {
        sequencerEngine->stop();
        std::cout << "⏸️  Sequencer STOPPED" << std::endl;
    }
    else if (command.substr(0, 6) == "engine") {
        try {
            int engine = std::stoi(command.substr(7));
            if (engine >= 0 && engine < 15) {
                stateManager->setCurrentEngine(engine);
                std::cout << "🎹 Switched to Engine " << engine << std::endl;
            } else {
                std::cout << "❌ Engine must be 0-14" << std::endl;
            }
        } catch (...) {
            std::cout << "❌ Usage: engine N (where N is 0-14)" << std::endl;
        }
    }
    else if (command.substr(0, 3) == "bpm") {
        try {
            float bpm = std::stof(command.substr(4));
            if (bpm >= 60.0f && bpm <= 200.0f) {
                sequencerEngine->setBPM(bpm);
                std::cout << "⏱️  BPM set to " << bpm << std::endl;
            } else {
                std::cout << "❌ BPM must be 60-200" << std::endl;
            }
        } catch (...) {
            std::cout << "❌ Usage: bpm N (where N is 60-200)" << std::endl;
        }
    }
    else if (command.substr(0, 4) == "step") {
        try {
            int step = std::stoi(command.substr(5));
            if (step >= 0 && step < 16) {
                int engine = stateManager->getCurrentEngine();
                auto currentStep = patternSystem->getStep(engine, step);

                if (currentStep.active) {
                    patternSystem->clearStep(engine, step);
                    std::cout << "○ Step " << step << " cleared" << std::endl;
                } else {
                    Pattern::StepData newStep;
                    newStep.active = true;
                    newStep.note = 60 + step;  // C4 + step
                    newStep.velocity = 0.8f;
                    newStep.hasAccent = (step % 4 == 0);
                    patternSystem->setStep(engine, step, newStep);
                    std::cout << "● Step " << step << " activated (note " << newStep.note << ")" << std::endl;
                }
            } else {
                std::cout << "❌ Step must be 0-15" << std::endl;
            }
        } catch (...) {
            std::cout << "❌ Usage: step N (where N is 0-15)" << std::endl;
        }
    }
    else if (command == "clear") {
        int engine = stateManager->getCurrentEngine();
        for (int step = 0; step < 16; ++step) {
            patternSystem->clearStep(engine, step);
        }
        std::cout << "🧹 Pattern cleared for engine " << engine << std::endl;
    }
    else if (command == "save") {
        int bank = stateManager->getCurrentPatternBank();
        int slot = stateManager->getCurrentPatternSlot();
        patternSystem->savePattern(bank, slot);
        std::cout << "💾 Pattern saved to bank " << bank << " slot " << slot << std::endl;
    }
    else if (command == "load") {
        int bank = stateManager->getCurrentPatternBank();
        int slot = stateManager->getCurrentPatternSlot();
        patternSystem->loadPattern(bank, slot);
        std::cout << "📂 Pattern loaded from bank " << bank << " slot " << slot << std::endl;
    }
    else if (command == "fx stutter") {
        if (fxSystem->isEffectActive(FX::PerformanceFX::STUTTER_SWEEP)) {
            fxSystem->deactivateEffect(FX::PerformanceFX::STUTTER_SWEEP);
            std::cout << "🎛️  Stutter FX OFF" << std::endl;
        } else {
            fxSystem->activateEffect(FX::PerformanceFX::STUTTER_SWEEP, 0.7f);
            std::cout << "🎛️  Stutter FX ON" << std::endl;
        }
    }
    else if (command == "fx reverse") {
        if (fxSystem->isEffectActive(FX::PerformanceFX::REVERSE)) {
            fxSystem->deactivateEffect(FX::PerformanceFX::REVERSE);
            std::cout << "🎛️  Reverse FX OFF" << std::endl;
        } else {
            fxSystem->activateEffect(FX::PerformanceFX::REVERSE, 0.8f);
            std::cout << "🎛️  Reverse FX ON" << std::endl;
        }
    }
    else if (command == "fx quantize") {
        if (fxSystem->isEffectActive(FX::PerformanceFX::QUANTIZE_6_8)) {
            fxSystem->deactivateEffect(FX::PerformanceFX::QUANTIZE_6_8);
            std::cout << "🎛️  6/8 Quantize FX OFF" << std::endl;
        } else {
            fxSystem->activateEffect(FX::PerformanceFX::QUANTIZE_6_8, 0.6f);
            std::cout << "🎛️  6/8 Quantize FX ON" << std::endl;
        }
    }
    else if (command == "status") {
        printStatus(sequencer);
    }
    else if (command.empty()) {
        // Ignore empty commands
    }
    else {
        std::cout << "❌ Unknown command: '" << command << "'. Type 'help' for commands." << std::endl;
    }
}

int main() {
    // Set up signal handlers for graceful shutdown
    signal(SIGINT, signalHandler);
    signal(SIGTERM, signalHandler);

    // Initialize logging (reduce verbosity for cleaner interface)
    Utils::Logger::getInstance().setLogLevel(Utils::LogLevel::WARNING);

    std::cout << "🎹 === MODULAR GRID SEQUENCER ===" << std::endl;
    std::cout << "🎵 Complete Modular Architecture" << std::endl;
    std::cout << "🚀 Initializing synthesizer..." << std::endl;

    try {
        // Create and initialize the modular sequencer
        g_sequencer = std::make_unique<ModularGridSequencer>();

        auto initResult = g_sequencer->initialize();
        if (initResult.isError()) {
            std::cerr << "❌ Failed to initialize modular sequencer: " << initResult.error() << std::endl;
            return 1;
        }

        std::cout << "✅ Modular Grid Sequencer initialized successfully!" << std::endl;
        std::cout << "🎼 15 synthesis engines loaded and ready" << std::endl;
        std::cout << "🎛️  Performance FX system active" << std::endl;
        std::cout << "🎹 Pattern system ready (64 pattern slots)" << std::endl;

        // Setup demo patterns
        auto patternSystem = g_sequencer->getPatternSystem();
        auto stateManager = g_sequencer->getStateManager();

        if (patternSystem && stateManager) {
            // Create a basic 4/4 kick pattern on engine 0
            for (int step = 0; step < 16; step += 4) {
                Pattern::StepData kickStep;
                kickStep.active = true;
                kickStep.note = 36; // Kick drum note
                kickStep.velocity = 0.9f;
                kickStep.hasAccent = (step == 0);
                patternSystem->setStep(0, step, kickStep);
            }

            // Create a snare pattern on engine 1
            for (int step = 4; step < 16; step += 8) {
                Pattern::StepData snareStep;
                snareStep.active = true;
                snareStep.note = 38; // Snare drum note
                snareStep.velocity = 0.8f;
                patternSystem->setStep(1, step, snareStep);
            }

            // Create a melodic pattern on engine 2
            int melody[] = {60, 64, 67, 72}; // C major chord notes
            for (int step = 0; step < 16; step += 2) {
                Pattern::StepData melodyStep;
                melodyStep.active = true;
                melodyStep.note = melody[step / 2 % 4];
                melodyStep.velocity = 0.6f;
                melodyStep.hasAccent = (step % 8 == 0);
                patternSystem->setStep(2, step, melodyStep);
            }

            stateManager->setCurrentEngine(0);
            std::cout << "🎵 Demo patterns loaded on engines 0, 1, and 2" << std::endl;
        }

        printHelp();
        printStatus(g_sequencer.get());

        // Interactive command loop
        std::string command;
        std::cout << "\n🎹 > ";
        while (g_running && std::getline(std::cin, command)) {
            processCommand(command, g_sequencer.get());

            if (g_running) {
                std::cout << "🎹 > ";
            }
        }

        // Graceful shutdown
        std::cout << "\n🛑 Shutting down modular sequencer..." << std::endl;
        g_sequencer->shutdown();
        g_sequencer.reset();

        std::cout << "✅ Clean shutdown complete. Thanks for using Modular Grid Sequencer!" << std::endl;
        return 0;

    } catch (const std::exception& e) {
        std::cerr << "❌ Exception: " << e.what() << std::endl;
        if (g_sequencer) {
            g_sequencer->shutdown();
        }
        return 1;
    }
}