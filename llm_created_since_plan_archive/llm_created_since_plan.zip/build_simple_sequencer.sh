#!/bin/bash
set -e

echo "=== Building Simple Modular Grid Sequencer ==="
echo ""

# Build configuration
CXXFLAGS="-std=c++17 -O2 -Wall -Wextra"
ENGINE_OBJS="src/engines/*.o src/synthesis/SynthEngine_minimal.o"
BRIDGE_OBJ="harmonized_13_engines_bridge.o"

echo "🔧 Building simple command-line modular sequencer..."

# Source files for the simple application
APP_SOURCES=(
    "simple_modular_sequencer.cpp"
    "src/grid_sequencer/ModularGridSequencer.cpp"
    "src/grid_sequencer/core/Application.cpp"
    "src/grid_sequencer/state/StateManager.cpp"
    "src/grid_sequencer/parameter/ParameterSystem.cpp"
    "src/grid_sequencer/audio/EtherSynthAudioEngine.cpp"
    "src/grid_sequencer/grid/MonomeGridController.cpp"
    "src/grid_sequencer/input/InputSystem.cpp"
    "src/grid_sequencer/ui/TerminalUISystem.cpp"
    "src/grid_sequencer/sequencer/SequencerEngine.cpp"
    "src/grid_sequencer/pattern/PatternSystem.cpp"
    "src/grid_sequencer/fx/PerformanceFXSystem.cpp"
)

# Build the simple application
g++ $CXXFLAGS \
    -I/opt/homebrew/include \
    -Isrc -Isrc/engines -Isrc/audio -Isrc/hardware -Isrc/data \
    -o simple_sequencer \
    "${APP_SOURCES[@]}" \
    $ENGINE_OBJS \
    $BRIDGE_OBJ \
    -L/opt/homebrew/lib \
    -lportaudio -pthread -llo

if [ $? -eq 0 ]; then
    echo "✅ Simple Modular Sequencer built successfully!"
    echo ""
    echo "🎹 Features:"
    echo "  • Simple command-line interface"
    echo "  • Text-based commands (no complex key handling)"
    echo "  • All 15 synthesis engines"
    echo "  • Pattern editing and playback"
    echo "  • Performance FX control"
    echo "  • Transport and BPM control"
    echo ""
    echo "🚀 Run with: ./simple_sequencer"
    echo ""
    echo "📋 Example commands:"
    echo "  help          - Show all commands"
    echo "  play          - Start/stop sequencer"
    echo "  engine 2      - Switch to engine 2"
    echo "  bpm 140       - Set BPM to 140"
    echo "  step 4        - Toggle step 4"
    echo "  fx stutter    - Toggle stutter effect"
    echo "  status        - Show current status"
    echo "  quit          - Exit"
else
    echo "❌ Build failed"
    exit 1
fi