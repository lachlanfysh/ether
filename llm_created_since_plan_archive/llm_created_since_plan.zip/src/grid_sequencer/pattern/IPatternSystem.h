#pragma once
#include "../core/DIContainer.h"
#include "../utils/Constants.h"
#include <vector>
#include <array>

namespace GridSequencer {
namespace Pattern {

using Core::Result;

// Step data for melodic patterns
struct StepData {
    bool active = false;
    int note = 60;
    float velocity = 0.6f;
    bool hasAccent = false;
    bool hasRetrigger = false;
    bool hasArpeggiator = false;

    // Default constructor and copy operations
    StepData() = default;
    StepData(const StepData&) = default;
    StepData& operator=(const StepData&) = default;
};

// Pattern storage types
using MelodicPattern = std::vector<StepData>; // Variable length patterns
using DrumPattern = std::array<uint16_t, 16>;  // 16 pads, each a 16-bit mask
using PatternBank = std::array<std::array<MelodicPattern, MAX_ENGINES>, 64>; // 64 patterns total

// Pattern metadata
struct PatternInfo {
    int bank;
    int slot;
    std::string name;
    bool isEmpty;
    int stepCount;
};

// Pattern system interface - manages step patterns and pattern banks
class IPatternSystem {
public:
    virtual ~IPatternSystem() = default;

    // System lifecycle
    virtual Result<bool> initialize() = 0;
    virtual void shutdown() = 0;
    virtual bool isInitialized() const = 0;

    // Melodic pattern access
    virtual StepData getStep(int engine, int step) const = 0;
    virtual Result<bool> setStep(int engine, int step, const StepData& data) = 0;
    virtual Result<bool> toggleStep(int engine, int step) = 0;
    virtual Result<bool> clearStep(int engine, int step) = 0;

    // Melodic pattern operations
    virtual int getPatternLength(int engine) const = 0;
    virtual Result<bool> setPatternLength(int engine, int length) = 0;
    virtual Result<bool> clearPattern(int engine) = 0;
    virtual bool isPatternEmpty(int engine) const = 0;

    // Drum pattern access
    virtual bool getDrumStep(int pad, int step) const = 0;
    virtual Result<bool> setDrumStep(int pad, int step, bool active) = 0;
    virtual Result<bool> toggleDrumStep(int pad, int step) = 0;
    virtual Result<bool> clearDrumStep(int pad, int step) = 0;
    virtual Result<bool> clearDrumPattern(int pad) = 0;
    virtual Result<bool> clearAllDrumPatterns() = 0;

    // Pattern bank management
    virtual Result<bool> savePattern(int bank, int slot) = 0;
    virtual Result<bool> loadPattern(int bank, int slot) = 0;
    virtual Result<bool> copyPattern(int sourceBank, int sourceSlot, int targetBank, int targetSlot) = 0;
    virtual Result<bool> clearPatternSlot(int bank, int slot) = 0;

    // Pattern bank information
    virtual PatternInfo getPatternInfo(int bank, int slot) const = 0;
    virtual std::vector<PatternInfo> getPatternList(int bank) const = 0;
    virtual bool isPatternSlotEmpty(int bank, int slot) const = 0;

    // Current pattern state
    virtual int getCurrentPatternBank() const = 0;
    virtual int getCurrentPatternSlot() const = 0;
    virtual Result<bool> setCurrentPattern(int bank, int slot) = 0;

    // Pattern effects and modifiers
    virtual Result<bool> setStepAccent(int engine, int step, bool accent) = 0;
    virtual Result<bool> setStepRetrigger(int engine, int step, bool retrigger) = 0;
    virtual Result<bool> setStepArpeggiator(int engine, int step, bool arpeggiator) = 0;

    // Pattern manipulation
    virtual Result<bool> reversePattern(int engine) = 0;
    virtual Result<bool> shufflePattern(int engine) = 0;
    virtual Result<bool> shiftPattern(int engine, int steps) = 0;
    virtual Result<bool> doublePattern(int engine) = 0;
    virtual Result<bool> halvePattern(int engine) = 0;

    // Step access by page (for 4x4 grid interaction)
    virtual int stepIndexFromPad(int padIndex, int page = 0) const = 0;
    virtual int padIndexFromStep(int stepIndex, int page = 0) const = 0;

    // Pattern validation
    virtual bool isValidEngine(int engine) const = 0;
    virtual bool isValidStep(int step) const = 0;
    virtual bool isValidPad(int pad) const = 0;
    virtual bool isValidBank(int bank) const = 0;
    virtual bool isValidSlot(int slot) const = 0;

    // Bulk operations
    virtual Result<bool> importPattern(int engine, const std::vector<StepData>& pattern) = 0;
    virtual std::vector<StepData> exportPattern(int engine) const = 0;
    virtual Result<bool> importDrumPattern(const DrumPattern& drumPattern) = 0;
    virtual DrumPattern exportDrumPattern() const = 0;
};

} // namespace Pattern
} // namespace GridSequencer