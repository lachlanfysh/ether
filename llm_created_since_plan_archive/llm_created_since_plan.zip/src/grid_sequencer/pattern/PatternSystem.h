#pragma once
#include "IPatternSystem.h"
#include "../state/IStateManager.h"
#include "../utils/Logger.h"
#include <memory>
#include <atomic>
#include <mutex>

namespace GridSequencer {
namespace Pattern {

using State::IStateManager;

class PatternSystem : public IPatternSystem {
public:
    explicit PatternSystem(std::shared_ptr<IStateManager> stateManager);
    virtual ~PatternSystem();

    // System lifecycle
    Result<bool> initialize() override;
    void shutdown() override;
    bool isInitialized() const override;

    // Melodic pattern access
    StepData getStep(int engine, int step) const override;
    Result<bool> setStep(int engine, int step, const StepData& data) override;
    Result<bool> toggleStep(int engine, int step) override;
    Result<bool> clearStep(int engine, int step) override;

    // Melodic pattern operations
    int getPatternLength(int engine) const override;
    Result<bool> setPatternLength(int engine, int length) override;
    Result<bool> clearPattern(int engine) override;
    bool isPatternEmpty(int engine) const override;

    // Drum pattern access
    bool getDrumStep(int pad, int step) const override;
    Result<bool> setDrumStep(int pad, int step, bool active) override;
    Result<bool> toggleDrumStep(int pad, int step) override;
    Result<bool> clearDrumStep(int pad, int step) override;
    Result<bool> clearDrumPattern(int pad) override;
    Result<bool> clearAllDrumPatterns() override;

    // Pattern bank management
    Result<bool> savePattern(int bank, int slot) override;
    Result<bool> loadPattern(int bank, int slot) override;
    Result<bool> copyPattern(int sourceBank, int sourceSlot, int targetBank, int targetSlot) override;
    Result<bool> clearPatternSlot(int bank, int slot) override;

    // Pattern bank information
    PatternInfo getPatternInfo(int bank, int slot) const override;
    std::vector<PatternInfo> getPatternList(int bank) const override;
    bool isPatternSlotEmpty(int bank, int slot) const override;

    // Current pattern state
    int getCurrentPatternBank() const override;
    int getCurrentPatternSlot() const override;
    Result<bool> setCurrentPattern(int bank, int slot) override;

    // Pattern effects and modifiers
    Result<bool> setStepAccent(int engine, int step, bool accent) override;
    Result<bool> setStepRetrigger(int engine, int step, bool retrigger) override;
    Result<bool> setStepArpeggiator(int engine, int step, bool arpeggiator) override;

    // Pattern manipulation
    Result<bool> reversePattern(int engine) override;
    Result<bool> shufflePattern(int engine) override;
    Result<bool> shiftPattern(int engine, int steps) override;
    Result<bool> doublePattern(int engine) override;
    Result<bool> halvePattern(int engine) override;

    // Step access by page (for 4x4 grid interaction)
    int stepIndexFromPad(int padIndex, int page = 0) const override;
    int padIndexFromStep(int stepIndex, int page = 0) const override;

    // Pattern validation
    bool isValidEngine(int engine) const override;
    bool isValidStep(int step) const override;
    bool isValidPad(int pad) const override;
    bool isValidBank(int bank) const override;
    bool isValidSlot(int slot) const override;

    // Bulk operations
    Result<bool> importPattern(int engine, const std::vector<StepData>& pattern) override;
    std::vector<StepData> exportPattern(int engine) const override;
    Result<bool> importDrumPattern(const DrumPattern& drumPattern) override;
    DrumPattern exportDrumPattern() const override;

private:
    std::shared_ptr<IStateManager> stateManager_;

    // Pattern storage
    std::array<MelodicPattern, MAX_ENGINES> enginePatterns_;
    DrumPattern drumMasks_;
    PatternBank patternBank_;

    // State
    std::atomic<bool> initialized_{false};
    mutable std::mutex patternMutex_;

    // Helper methods
    void ensurePatternSize(int engine, int stepIndex);
    int getAbsolutePatternIndex(int bank, int slot) const;
    bool isPatternSlotEmptyInternal(int bank, int slot) const;
    void clearPatternInternal(int engine);
    void clearDrumPatternsInternal();
};

} // namespace Pattern
} // namespace GridSequencer