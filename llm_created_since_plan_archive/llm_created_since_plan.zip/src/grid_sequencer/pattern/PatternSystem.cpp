#include "PatternSystem.h"
#include "../utils/Constants.h"
#include <algorithm>
#include <random>

namespace GridSequencer {
namespace Pattern {

PatternSystem::PatternSystem(std::shared_ptr<IStateManager> stateManager)
    : stateManager_(stateManager) {

    LOG_INFO("PatternSystem created");

    // Initialize drum masks to zero
    drumMasks_.fill(0);

    // Initialize all patterns
    for (int engine = 0; engine < MAX_ENGINES; ++engine) {
        enginePatterns_[engine].resize(GRID_PATTERN_STEPS);
        for (int step = 0; step < GRID_PATTERN_STEPS; ++step) {
            enginePatterns_[engine][step] = StepData(); // Default constructor
        }
    }

    // Initialize pattern bank
    for (int pattern = 0; pattern < 64; ++pattern) {
        for (int engine = 0; engine < MAX_ENGINES; ++engine) {
            patternBank_[pattern][engine].resize(GRID_PATTERN_STEPS);
            for (int step = 0; step < GRID_PATTERN_STEPS; ++step) {
                patternBank_[pattern][engine][step] = StepData();
            }
        }
    }
}

PatternSystem::~PatternSystem() {
    shutdown();
    LOG_INFO("PatternSystem destroyed");
}

Result<bool> PatternSystem::initialize() {
    if (initialized_.load()) {
        return Result<bool>::success(true);
    }

    LOG_INFO("Initializing PatternSystem...");

    initialized_ = true;
    LOG_INFO("PatternSystem initialized");
    return Result<bool>::success(true);
}

void PatternSystem::shutdown() {
    if (!initialized_.load()) {
        return;
    }

    LOG_INFO("Shutting down PatternSystem...");
    initialized_ = false;
    LOG_INFO("PatternSystem shut down");
}

bool PatternSystem::isInitialized() const {
    return initialized_.load();
}

// Melodic pattern access
StepData PatternSystem::getStep(int engine, int step) const {
    std::lock_guard<std::mutex> lock(patternMutex_);

    if (!isValidEngine(engine) || !isValidStep(step)) {
        return StepData(); // Return default step
    }

    if (step >= static_cast<int>(enginePatterns_[engine].size())) {
        return StepData(); // Return default for out-of-range steps
    }

    return enginePatterns_[engine][step];
}

Result<bool> PatternSystem::setStep(int engine, int step, const StepData& data) {
    if (!isValidEngine(engine) || !isValidStep(step)) {
        return Result<bool>::error("Invalid engine or step");
    }

    std::lock_guard<std::mutex> lock(patternMutex_);
    ensurePatternSize(engine, step);
    enginePatterns_[engine][step] = data;

    return Result<bool>::success(true);
}

Result<bool> PatternSystem::toggleStep(int engine, int step) {
    if (!isValidEngine(engine) || !isValidStep(step)) {
        return Result<bool>::error("Invalid engine or step");
    }

    std::lock_guard<std::mutex> lock(patternMutex_);
    ensurePatternSize(engine, step);
    enginePatterns_[engine][step].active = !enginePatterns_[engine][step].active;

    return Result<bool>::success(true);
}

Result<bool> PatternSystem::clearStep(int engine, int step) {
    if (!isValidEngine(engine) || !isValidStep(step)) {
        return Result<bool>::error("Invalid engine or step");
    }

    std::lock_guard<std::mutex> lock(patternMutex_);
    if (step < static_cast<int>(enginePatterns_[engine].size())) {
        enginePatterns_[engine][step] = StepData(); // Reset to default
    }

    return Result<bool>::success(true);
}

// Melodic pattern operations
int PatternSystem::getPatternLength(int engine) const {
    if (!isValidEngine(engine)) {
        return 0;
    }

    std::lock_guard<std::mutex> lock(patternMutex_);
    return static_cast<int>(enginePatterns_[engine].size());
}

Result<bool> PatternSystem::setPatternLength(int engine, int length) {
    if (!isValidEngine(engine) || length < 1 || length > 64) {
        return Result<bool>::error("Invalid engine or pattern length");
    }

    std::lock_guard<std::mutex> lock(patternMutex_);
    enginePatterns_[engine].resize(length);

    // Initialize new steps if pattern was extended
    for (int i = 0; i < length; ++i) {
        if (i >= static_cast<int>(enginePatterns_[engine].size()) ||
            enginePatterns_[engine].size() <= static_cast<size_t>(i)) {
            enginePatterns_[engine][i] = StepData();
        }
    }

    return Result<bool>::success(true);
}

Result<bool> PatternSystem::clearPattern(int engine) {
    if (!isValidEngine(engine)) {
        return Result<bool>::error("Invalid engine");
    }

    std::lock_guard<std::mutex> lock(patternMutex_);
    clearPatternInternal(engine);

    return Result<bool>::success(true);
}

bool PatternSystem::isPatternEmpty(int engine) const {
    if (!isValidEngine(engine)) {
        return true;
    }

    std::lock_guard<std::mutex> lock(patternMutex_);
    for (const auto& step : enginePatterns_[engine]) {
        if (step.active) {
            return false;
        }
    }
    return true;
}

// Drum pattern access
bool PatternSystem::getDrumStep(int pad, int step) const {
    if (!isValidPad(pad) || !isValidStep(step)) {
        return false;
    }

    std::lock_guard<std::mutex> lock(patternMutex_);
    return (drumMasks_[pad] >> step) & 1u;
}

Result<bool> PatternSystem::setDrumStep(int pad, int step, bool active) {
    if (!isValidPad(pad) || !isValidStep(step)) {
        return Result<bool>::error("Invalid pad or step");
    }

    std::lock_guard<std::mutex> lock(patternMutex_);
    if (active) {
        drumMasks_[pad] |= (1u << step);
    } else {
        drumMasks_[pad] &= ~(1u << step);
    }

    return Result<bool>::success(true);
}

Result<bool> PatternSystem::toggleDrumStep(int pad, int step) {
    if (!isValidPad(pad) || !isValidStep(step)) {
        return Result<bool>::error("Invalid pad or step");
    }

    std::lock_guard<std::mutex> lock(patternMutex_);
    drumMasks_[pad] ^= (1u << step);

    return Result<bool>::success(true);
}

Result<bool> PatternSystem::clearDrumStep(int pad, int step) {
    if (!isValidPad(pad) || !isValidStep(step)) {
        return Result<bool>::error("Invalid pad or step");
    }

    std::lock_guard<std::mutex> lock(patternMutex_);
    drumMasks_[pad] &= ~(1u << step);

    return Result<bool>::success(true);
}

Result<bool> PatternSystem::clearDrumPattern(int pad) {
    if (!isValidPad(pad)) {
        return Result<bool>::error("Invalid pad");
    }

    std::lock_guard<std::mutex> lock(patternMutex_);
    drumMasks_[pad] = 0;

    return Result<bool>::success(true);
}

Result<bool> PatternSystem::clearAllDrumPatterns() {
    std::lock_guard<std::mutex> lock(patternMutex_);
    clearDrumPatternsInternal();

    return Result<bool>::success(true);
}

// Pattern bank management
Result<bool> PatternSystem::savePattern(int bank, int slot) {
    if (!isValidBank(bank) || !isValidSlot(slot)) {
        return Result<bool>::error("Invalid bank or slot");
    }

    std::lock_guard<std::mutex> lock(patternMutex_);
    int absoluteIndex = getAbsolutePatternIndex(bank, slot);

    // Copy current patterns to bank
    for (int engine = 0; engine < MAX_ENGINES; ++engine) {
        patternBank_[absoluteIndex][engine] = enginePatterns_[engine];
    }

    LOG_INFO("Saved pattern to bank " + std::to_string(bank) + ", slot " + std::to_string(slot));
    return Result<bool>::success(true);
}

Result<bool> PatternSystem::loadPattern(int bank, int slot) {
    if (!isValidBank(bank) || !isValidSlot(slot)) {
        return Result<bool>::error("Invalid bank or slot");
    }

    std::lock_guard<std::mutex> lock(patternMutex_);
    int absoluteIndex = getAbsolutePatternIndex(bank, slot);

    // Copy pattern from bank to current patterns
    for (int engine = 0; engine < MAX_ENGINES; ++engine) {
        enginePatterns_[engine] = patternBank_[absoluteIndex][engine];
    }

    // Update state manager
    if (stateManager_) {
        stateManager_->setCurrentPatternBank(bank);
        stateManager_->setCurrentPatternSlot(slot);
    }

    LOG_INFO("Loaded pattern from bank " + std::to_string(bank) + ", slot " + std::to_string(slot));
    return Result<bool>::success(true);
}

Result<bool> PatternSystem::copyPattern(int sourceBank, int sourceSlot, int targetBank, int targetSlot) {
    if (!isValidBank(sourceBank) || !isValidSlot(sourceSlot) ||
        !isValidBank(targetBank) || !isValidSlot(targetSlot)) {
        return Result<bool>::error("Invalid bank or slot parameters");
    }

    std::lock_guard<std::mutex> lock(patternMutex_);
    int sourceIndex = getAbsolutePatternIndex(sourceBank, sourceSlot);
    int targetIndex = getAbsolutePatternIndex(targetBank, targetSlot);

    // Copy pattern from source to target
    for (int engine = 0; engine < MAX_ENGINES; ++engine) {
        patternBank_[targetIndex][engine] = patternBank_[sourceIndex][engine];
    }

    LOG_INFO("Copied pattern from bank " + std::to_string(sourceBank) + "/" + std::to_string(sourceSlot) +
             " to bank " + std::to_string(targetBank) + "/" + std::to_string(targetSlot));
    return Result<bool>::success(true);
}

Result<bool> PatternSystem::clearPatternSlot(int bank, int slot) {
    if (!isValidBank(bank) || !isValidSlot(slot)) {
        return Result<bool>::error("Invalid bank or slot");
    }

    std::lock_guard<std::mutex> lock(patternMutex_);
    int absoluteIndex = getAbsolutePatternIndex(bank, slot);

    // Clear all patterns in this slot
    for (int engine = 0; engine < MAX_ENGINES; ++engine) {
        patternBank_[absoluteIndex][engine].clear();
        patternBank_[absoluteIndex][engine].resize(GRID_PATTERN_STEPS);
        for (int step = 0; step < GRID_PATTERN_STEPS; ++step) {
            patternBank_[absoluteIndex][engine][step] = StepData();
        }
    }

    LOG_INFO("Cleared pattern slot bank " + std::to_string(bank) + ", slot " + std::to_string(slot));
    return Result<bool>::success(true);
}

// Pattern bank information
PatternInfo PatternSystem::getPatternInfo(int bank, int slot) const {
    PatternInfo info;
    info.bank = bank;
    info.slot = slot;
    info.name = "Pattern " + std::to_string(getAbsolutePatternIndex(bank, slot) + 1);
    info.isEmpty = isPatternSlotEmpty(bank, slot);
    info.stepCount = GRID_PATTERN_STEPS;

    return info;
}

std::vector<PatternInfo> PatternSystem::getPatternList(int bank) const {
    std::vector<PatternInfo> patterns;

    if (!isValidBank(bank)) {
        return patterns;
    }

    for (int slot = 0; slot < 16; ++slot) {
        patterns.push_back(getPatternInfo(bank, slot));
    }

    return patterns;
}

bool PatternSystem::isPatternSlotEmpty(int bank, int slot) const {
    if (!isValidBank(bank) || !isValidSlot(slot)) {
        return true;
    }

    std::lock_guard<std::mutex> lock(patternMutex_);
    return isPatternSlotEmptyInternal(bank, slot);
}

// Current pattern state
int PatternSystem::getCurrentPatternBank() const {
    return stateManager_ ? stateManager_->getCurrentPatternBank() : 0;
}

int PatternSystem::getCurrentPatternSlot() const {
    return stateManager_ ? stateManager_->getCurrentPatternSlot() : 0;
}

Result<bool> PatternSystem::setCurrentPattern(int bank, int slot) {
    if (!isValidBank(bank) || !isValidSlot(slot)) {
        return Result<bool>::error("Invalid bank or slot");
    }

    if (stateManager_) {
        stateManager_->setCurrentPatternBank(bank);
        stateManager_->setCurrentPatternSlot(slot);
    }

    return Result<bool>::success(true);
}

// Pattern effects and modifiers
Result<bool> PatternSystem::setStepAccent(int engine, int step, bool accent) {
    if (!isValidEngine(engine) || !isValidStep(step)) {
        return Result<bool>::error("Invalid engine or step");
    }

    std::lock_guard<std::mutex> lock(patternMutex_);
    ensurePatternSize(engine, step);
    enginePatterns_[engine][step].hasAccent = accent;

    return Result<bool>::success(true);
}

Result<bool> PatternSystem::setStepRetrigger(int engine, int step, bool retrigger) {
    if (!isValidEngine(engine) || !isValidStep(step)) {
        return Result<bool>::error("Invalid engine or step");
    }

    std::lock_guard<std::mutex> lock(patternMutex_);
    ensurePatternSize(engine, step);
    enginePatterns_[engine][step].hasRetrigger = retrigger;

    // Mutually exclusive with arpeggiator
    if (retrigger) {
        enginePatterns_[engine][step].hasArpeggiator = false;
    }

    return Result<bool>::success(true);
}

Result<bool> PatternSystem::setStepArpeggiator(int engine, int step, bool arpeggiator) {
    if (!isValidEngine(engine) || !isValidStep(step)) {
        return Result<bool>::error("Invalid engine or step");
    }

    std::lock_guard<std::mutex> lock(patternMutex_);
    ensurePatternSize(engine, step);
    enginePatterns_[engine][step].hasArpeggiator = arpeggiator;

    // Mutually exclusive with retrigger
    if (arpeggiator) {
        enginePatterns_[engine][step].hasRetrigger = false;
    }

    return Result<bool>::success(true);
}

// Pattern manipulation
Result<bool> PatternSystem::reversePattern(int engine) {
    if (!isValidEngine(engine)) {
        return Result<bool>::error("Invalid engine");
    }

    std::lock_guard<std::mutex> lock(patternMutex_);
    std::reverse(enginePatterns_[engine].begin(), enginePatterns_[engine].end());

    return Result<bool>::success(true);
}

Result<bool> PatternSystem::shufflePattern(int engine) {
    if (!isValidEngine(engine)) {
        return Result<bool>::error("Invalid engine");
    }

    std::lock_guard<std::mutex> lock(patternMutex_);
    static std::random_device rd;
    static std::mt19937 g(rd());
    std::shuffle(enginePatterns_[engine].begin(), enginePatterns_[engine].end(), g);

    return Result<bool>::success(true);
}

Result<bool> PatternSystem::shiftPattern(int engine, int steps) {
    if (!isValidEngine(engine)) {
        return Result<bool>::error("Invalid engine");
    }

    std::lock_guard<std::mutex> lock(patternMutex_);
    if (enginePatterns_[engine].empty()) {
        return Result<bool>::success(true);
    }

    int patternLength = static_cast<int>(enginePatterns_[engine].size());
    steps = steps % patternLength; // Handle steps > pattern length

    if (steps == 0) {
        return Result<bool>::success(true);
    }

    // Positive steps = shift right, negative = shift left
    if (steps > 0) {
        std::rotate(enginePatterns_[engine].rbegin(),
                   enginePatterns_[engine].rbegin() + steps,
                   enginePatterns_[engine].rend());
    } else {
        std::rotate(enginePatterns_[engine].begin(),
                   enginePatterns_[engine].begin() + (-steps),
                   enginePatterns_[engine].end());
    }

    return Result<bool>::success(true);
}

Result<bool> PatternSystem::doublePattern(int engine) {
    if (!isValidEngine(engine)) {
        return Result<bool>::error("Invalid engine");
    }

    std::lock_guard<std::mutex> lock(patternMutex_);
    auto originalPattern = enginePatterns_[engine];
    enginePatterns_[engine].insert(enginePatterns_[engine].end(),
                                  originalPattern.begin(),
                                  originalPattern.end());

    return Result<bool>::success(true);
}

Result<bool> PatternSystem::halvePattern(int engine) {
    if (!isValidEngine(engine)) {
        return Result<bool>::error("Invalid engine");
    }

    std::lock_guard<std::mutex> lock(patternMutex_);
    int newLength = std::max(1, static_cast<int>(enginePatterns_[engine].size()) / 2);
    enginePatterns_[engine].resize(newLength);

    return Result<bool>::success(true);
}

// Step access by page
int PatternSystem::stepIndexFromPad(int padIndex, int page) const {
    if (padIndex < 0 || padIndex >= GRID_WIDTH || page < 0) {
        return -1;
    }
    return page * GRID_WIDTH + padIndex;
}

int PatternSystem::padIndexFromStep(int stepIndex, int page) const {
    if (stepIndex < 0 || page < 0) {
        return -1;
    }
    return stepIndex - (page * GRID_WIDTH);
}

// Pattern validation
bool PatternSystem::isValidEngine(int engine) const {
    return engine >= 0 && engine < MAX_ENGINES;
}

bool PatternSystem::isValidStep(int step) const {
    return step >= 0 && step < 64; // Support up to 64 steps
}

bool PatternSystem::isValidPad(int pad) const {
    return pad >= 0 && pad < 16; // 16 drum pads
}

bool PatternSystem::isValidBank(int bank) const {
    return bank >= 0 && bank < 4; // 4 banks
}

bool PatternSystem::isValidSlot(int slot) const {
    return slot >= 0 && slot < 16; // 16 slots per bank
}

// Bulk operations
Result<bool> PatternSystem::importPattern(int engine, const std::vector<StepData>& pattern) {
    if (!isValidEngine(engine)) {
        return Result<bool>::error("Invalid engine");
    }

    std::lock_guard<std::mutex> lock(patternMutex_);
    enginePatterns_[engine] = pattern;

    return Result<bool>::success(true);
}

std::vector<StepData> PatternSystem::exportPattern(int engine) const {
    if (!isValidEngine(engine)) {
        return std::vector<StepData>();
    }

    std::lock_guard<std::mutex> lock(patternMutex_);
    return enginePatterns_[engine];
}

Result<bool> PatternSystem::importDrumPattern(const DrumPattern& drumPattern) {
    std::lock_guard<std::mutex> lock(patternMutex_);
    drumMasks_ = drumPattern;

    return Result<bool>::success(true);
}

DrumPattern PatternSystem::exportDrumPattern() const {
    std::lock_guard<std::mutex> lock(patternMutex_);
    return drumMasks_;
}

// Private helper methods
void PatternSystem::ensurePatternSize(int engine, int stepIndex) {
    if (stepIndex >= static_cast<int>(enginePatterns_[engine].size())) {
        enginePatterns_[engine].resize(stepIndex + 1);
    }
}

int PatternSystem::getAbsolutePatternIndex(int bank, int slot) const {
    return bank * 16 + slot; // 16 slots per bank
}

bool PatternSystem::isPatternSlotEmptyInternal(int bank, int slot) const {
    int absoluteIndex = getAbsolutePatternIndex(bank, slot);

    for (int engine = 0; engine < MAX_ENGINES; ++engine) {
        for (const auto& step : patternBank_[absoluteIndex][engine]) {
            if (step.active) {
                return false;
            }
        }
    }
    return true;
}

void PatternSystem::clearPatternInternal(int engine) {
    for (auto& step : enginePatterns_[engine]) {
        step.active = false;
    }
}

void PatternSystem::clearDrumPatternsInternal() {
    drumMasks_.fill(0);
}

} // namespace Pattern
} // namespace GridSequencer