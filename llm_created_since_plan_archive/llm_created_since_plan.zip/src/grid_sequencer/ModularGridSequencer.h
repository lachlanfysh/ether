#pragma once
#include "core/Application.h"
#include "sequencer/SequencerEngine.h"
#include "pattern/PatternSystem.h"
#include "fx/PerformanceFXSystem.h"
#include "grid/MonomeGridController.h"
#include "input/InputSystem.h"
#include "ui/TerminalUISystem.h"
#include <memory>

namespace GridSequencer {

// Complete modular grid sequencer application
class ModularGridSequencer {
public:
    ModularGridSequencer();
    ~ModularGridSequencer();

    // Application lifecycle
    Core::Result<bool> initialize();
    void shutdown();
    bool isInitialized() const;

    // Main run loop
    void run();

    // Component access
    std::shared_ptr<Core::Application> getApplication() const { return app_; }
    std::shared_ptr<Pattern::PatternSystem> getPatternSystem() const { return patternSystem_; }
    std::shared_ptr<Sequencer::SequencerEngine> getSequencerEngine() const { return sequencerEngine_; }
    std::shared_ptr<FX::PerformanceFXSystem> getFXSystem() const { return fxSystem_; }
    std::shared_ptr<Grid::MonomeGridController> getGridController() const { return gridController_; }
    std::shared_ptr<Input::InputSystem> getInputSystem() const { return inputSystem_; }
    std::shared_ptr<UI::TerminalUISystem> getUISystem() const { return uiSystem_; }

    // Core component access (from DI container)
    std::shared_ptr<State::IStateManager> getStateManager() const;
    std::shared_ptr<Parameter::IParameterSystem> getParameterSystem() const;
    std::shared_ptr<Audio::IAudioEngine> getAudioEngine() const;

private:
    // Core application (Phase 1 & 2)
    std::shared_ptr<Core::Application> app_;

    // Phase 3: Input/Output Systems
    std::shared_ptr<Grid::MonomeGridController> gridController_;
    std::shared_ptr<Input::InputSystem> inputSystem_;
    std::shared_ptr<UI::TerminalUISystem> uiSystem_;

    // Phase 4: Sequencer Logic Systems
    std::shared_ptr<Pattern::PatternSystem> patternSystem_;
    std::shared_ptr<Sequencer::SequencerEngine> sequencerEngine_;
    std::shared_ptr<FX::PerformanceFXSystem> fxSystem_;

    // State
    bool initialized_ = false;
    bool running_ = false;

    // Setup methods
    void setupCallbacks();
    void setupDefaultPatterns();
    void setupUI();
};

} // namespace GridSequencer