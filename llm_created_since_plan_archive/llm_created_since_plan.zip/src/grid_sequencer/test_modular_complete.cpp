#include "ModularGridSequencer.h"
#include "utils/Logger.h"
#include <iostream>
#include <thread>
#include <chrono>
#include <signal.h>

using namespace GridSequencer;

// Global instance for signal handling
std::unique_ptr<ModularGridSequencer> g_sequencer;
volatile bool g_running = true;

void signalHandler(int signal) {
    std::cout << "\nReceived signal " << signal << ", shutting down gracefully..." << std::endl;
    g_running = false;
    if (g_sequencer) {
        g_sequencer->shutdown();
    }
}

int main() {
    // Set up signal handlers for graceful shutdown
    signal(SIGINT, signalHandler);
    signal(SIGTERM, signalHandler);

    // Initialize logging
    Utils::Logger::getInstance().setLogLevel(Utils::LogLevel::INFO);

    std::cout << "=== Complete Modular Grid Sequencer ===" << std::endl;
    std::cout << "Transformed from monolithic grid_sequencer_advanced.cpp" << std::endl;
    std::cout << "into a clean, modular, maintainable architecture!" << std::endl;
    std::cout << "\nPress Ctrl+C to stop\n" << std::endl;

    try {
        // Create and initialize the complete modular sequencer
        g_sequencer = std::make_unique<ModularGridSequencer>();

        auto initResult = g_sequencer->initialize();
        if (initResult.isError()) {
            std::cerr << "Failed to initialize modular sequencer: " << initResult.error() << std::endl;
            return 1;
        }

        std::cout << "✅ Complete modular grid sequencer initialized!" << std::endl;

        // Print system information
        std::cout << "\n--- System Components ---" << std::endl;
        std::cout << "Phase 1: Foundation - ✅ DIContainer, Logger, Result types" << std::endl;
        std::cout << "Phase 2: Core Systems - ✅ AudioEngine, ParameterSystem, StateManager" << std::endl;
        std::cout << "Phase 3: Input/Output - ✅ GridController, InputSystem, UISystem" << std::endl;
        std::cout << "Phase 4: Sequencer Logic - ✅ SequencerEngine, PatternSystem, PerformanceFX" << std::endl;
        std::cout << "Phase 5: Integration - ✅ ModularGridSequencer application" << std::endl;

        // Get components for demonstration
        auto stateManager = g_sequencer->getStateManager();
        auto parameterSystem = g_sequencer->getParameterSystem();
        auto audioEngine = g_sequencer->getAudioEngine();
        auto patternSystem = g_sequencer->getPatternSystem();
        auto sequencerEngine = g_sequencer->getSequencerEngine();
        auto fxSystem = g_sequencer->getFXSystem();

        if (!stateManager || !parameterSystem || !audioEngine ||
            !patternSystem || !sequencerEngine || !fxSystem) {
            std::cerr << "Failed to resolve components from modular architecture" << std::endl;
            return 1;
        }

        // Demonstrate modular functionality
        std::cout << "\n--- Demonstrating Modular Architecture ---" << std::endl;

        // 1. Pattern System
        std::cout << "Pattern System: Creating and manipulating patterns..." << std::endl;
        Pattern::StepData step;
        step.active = true;
        step.note = 60;
        step.velocity = 0.8f;
        step.hasAccent = true;
        patternSystem->setStep(0, 0, step);
        patternSystem->savePattern(0, 1);
        std::cout << "  ✓ Pattern created and saved to bank 0, slot 1" << std::endl;

        // 2. Sequencer Engine
        std::cout << "Sequencer Engine: Configuring timing and transport..." << std::endl;
        sequencerEngine->setBPM(140.0f);
        sequencerEngine->setPatternLength(16);
        sequencerEngine->enableSwing(true);
        sequencerEngine->setSwing(0.3f);
        std::cout << "  ✓ BPM: " << sequencerEngine->getBPM() << ", Swing: " << sequencerEngine->getSwing() << std::endl;

        // 3. Performance FX System
        std::cout << "Performance FX: Activating real-time effects..." << std::endl;
        fxSystem->activateEffect(FX::PerformanceFX::STUTTER_SWEEP, 0.5f);
        fxSystem->activateEffect(FX::PerformanceFX::QUANTIZE_6_8, 0.7f);
        std::cout << "  ✓ Active FX: " << fxSystem->getActiveEffectCount() << " effects running" << std::endl;

        // 4. Parameter System
        std::cout << "Parameter System: Setting synthesis parameters..." << std::endl;
        parameterSystem->setParameter(0, ParameterID::FILTER_CUTOFF, 0.75f);
        parameterSystem->setParameter(0, ParameterID::FILTER_RESONANCE, 0.4f);
        parameterSystem->setParameter(1, ParameterID::VOLUME, 0.9f);
        auto cutoffResult = parameterSystem->getParameter(0, ParameterID::FILTER_CUTOFF);
        float cutoff = cutoffResult.isSuccess() ? cutoffResult.value() : 0.0f;
        std::cout << "  ✓ Filter cutoff set to: " << cutoff << std::endl;

        // 5. State Management
        std::cout << "State Manager: Coordinating application state..." << std::endl;
        stateManager->setCurrentEngine(1);
        stateManager->setCurrentPatternBank(0);
        stateManager->setCurrentPatternSlot(1);
        std::cout << "  ✓ Current engine: " << stateManager->getCurrentEngine() << std::endl;

        // 6. Audio Engine Integration
        std::cout << "Audio Engine: Ready for synthesis..." << std::endl;
        std::cout << "  ✓ Initialized: " << (audioEngine->isInitialized() ? "YES" : "NO") << std::endl;
        std::cout << "  ✓ Active voices: " << audioEngine->getActiveVoiceCount() << std::endl;

        // Start the sequencer for demonstration
        std::cout << "\n⏵  Starting sequencer for live demonstration..." << std::endl;
        sequencerEngine->play();

        // Show live status updates
        int updateCount = 0;
        while (g_running && updateCount < 20) { // Run for ~10 seconds
            auto currentStep = stateManager->getCurrentStep();
            auto isPlaying = stateManager->isPlaying();
            auto fxCount = fxSystem->getActiveEffectCount();

            std::cout << "\rStep: " << std::setw(2) << currentStep
                      << " | Playing: " << (isPlaying ? "YES" : "NO ")
                      << " | FX: " << fxCount
                      << " | BPM: " << sequencerEngine->getBPM()
                      << " | Engine: " << stateManager->getCurrentEngine()
                      << std::flush;

            // Demonstrate dynamic FX changes
            if (updateCount == 10) {
                fxSystem->activateEffect(FX::PerformanceFX::REVERSE, 0.8f);
                std::cout << "\n  🎛️  Added REVERSE effect dynamically!" << std::endl;
            }

            std::this_thread::sleep_for(std::chrono::milliseconds(500));
            updateCount++;
        }

        std::cout << std::endl;

        // Stop sequencer
        sequencerEngine->stop();
        std::cout << "✅ Sequencer stopped" << std::endl;

        // Demonstrate pattern bank functionality
        std::cout << "\n--- Pattern Bank System ---" << std::endl;
        for (int bank = 0; bank < 2; ++bank) {
            for (int slot = 0; slot < 4; ++slot) {
                auto info = patternSystem->getPatternInfo(bank, slot);
                std::cout << "Bank " << bank << " Slot " << slot << ": "
                          << info.name << (info.isEmpty ? " (empty)" : " (has data)") << std::endl;
            }
        }

        // Demonstrate modular architecture benefits
        std::cout << "\n--- Architecture Benefits Demonstrated ---" << std::endl;
        std::cout << "✅ Isolated Components: Each system operates independently" << std::endl;
        std::cout << "✅ Dependency Injection: Loose coupling between systems" << std::endl;
        std::cout << "✅ Interface-Based Design: Easy to test and extend" << std::endl;
        std::cout << "✅ Error Handling: Comprehensive Result<T> throughout" << std::endl;
        std::cout << "✅ Thread Safety: Concurrent operations with proper synchronization" << std::endl;
        std::cout << "✅ Maintainability: Clear separation of concerns" << std::endl;
        std::cout << "✅ Extensibility: New features can be added without affecting existing code" << std::endl;

        std::cout << "\n🎉 Modular architecture demonstration complete!" << std::endl;
        std::cout << "The transformation from monolithic to modular is successful!" << std::endl;

        // Wait for user to stop or signal
        if (g_running) {
            std::cout << "\nPress Ctrl+C to exit..." << std::endl;
            while (g_running) {
                std::this_thread::sleep_for(std::chrono::milliseconds(100));
            }
        }

        // Graceful shutdown
        std::cout << "\nShutting down modular sequencer..." << std::endl;
        g_sequencer->shutdown();
        g_sequencer.reset();

        std::cout << "✅ Clean shutdown complete" << std::endl;
        return 0;

    } catch (const std::exception& e) {
        std::cerr << "❌ Exception: " << e.what() << std::endl;
        if (g_sequencer) {
            g_sequencer->shutdown();
        }
        return 1;
    }
}