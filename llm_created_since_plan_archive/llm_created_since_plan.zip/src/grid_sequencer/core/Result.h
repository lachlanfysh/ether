#pragma once
#include <stdexcept>
#include <string>
#include <utility>
#include <iomanip>

namespace GridSequencer {
namespace Core {

// Fixed Result template that avoids constructor ambiguity
template<typename T>
class Result {
private:
    struct SuccessTag {};
    struct ErrorTag {};

public:
    // Static factory methods to avoid constructor ambiguity
    static Result success(T value) {
        Result result;
        result.value_ = std::move(value);
        result.hasValue_ = true;
        return result;
    }

    static Result error(const std::string& message) {
        Result result;
        result.error_ = message;
        result.hasValue_ = false;
        return result;
    }

    // Query methods
    bool isSuccess() const { return hasValue_; }
    bool isError() const { return !hasValue_; }

    // Value access
    const T& value() const {
        if (!hasValue_) {
            throw std::runtime_error("Accessing value of error result: " + error_);
        }
        return value_;
    }

    // Error access
    const std::string& error() const {
        if (hasValue_) {
            throw std::runtime_error("Accessing error of success result");
        }
        return error_;
    }

    // Move semantics support
    T&& moveValue() {
        if (!hasValue_) {
            throw std::runtime_error("Accessing value of error result: " + error_);
        }
        return std::move(value_);
    }

private:
    // Private constructor to force use of factory methods
    Result() = default;

    T value_{};
    std::string error_;
    bool hasValue_{false};
};

} // namespace Core
} // namespace GridSequencer