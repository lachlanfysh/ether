#pragma once
#include "IPerformanceFXSystem.h"
#include "../pattern/IPatternSystem.h"
#include "../utils/Logger.h"
#include <memory>
#include <atomic>
#include <mutex>
#include <chrono>

namespace GridSequencer {
namespace FX {

using Pattern::IPatternSystem;

class PerformanceFXSystem : public IPerformanceFXSystem {
public:
    explicit PerformanceFXSystem(std::shared_ptr<IPatternSystem> patternSystem);
    virtual ~PerformanceFXSystem();

    // System lifecycle
    Result<bool> initialize() override;
    void shutdown() override;
    bool isInitialized() const override;

    // Effect management
    Result<bool> activateEffect(PerformanceFX effect, float intensity = 1.0f) override;
    Result<bool> deactivateEffect(PerformanceFX effect) override;
    void clearAllEffects() override;
    bool isEffectActive(PerformanceFX effect) const override;
    float getEffectIntensity(PerformanceFX effect) const override;

    // Effect stacking
    std::set<PerformanceFX> getActiveEffects() const override;
    int getActiveEffectCount() const override;

    // Step progression with FX
    int getNextStep(int currentStep) const override;
    void updateStepCounter() override;

    // Audio processing
    void processAudioBuffer(float* audioBuffer, size_t bufferSize) override;
    void setAudioProcessCallback(AudioProcessCallback callback) override;

    // Pattern manipulation
    Result<bool> bakeEffectIntoPattern(PerformanceFX effect) override;
    Result<bool> backupCurrentPattern() override;
    Result<bool> restoreOriginalPattern() override;

    // Timing control
    void setBPM(float bpm) override;
    float getBPM() const override;
    void setStepInterval(double intervalSeconds) override;
    double getStepInterval() const override;

    // Effect-specific parameters
    Result<bool> setLoopLength(int length) override;
    int getLoopLength() const override;
    Result<bool> setStutterRate(int rate) override;
    int getStutterRate() const override;

    // FX mode state
    void setFXModeActive(bool active) override;
    bool isFXModeActive() const override;

    // Effect information
    std::string getEffectName(PerformanceFX effect) const override;
    std::vector<std::string> getAllEffectNames() const override;

    // Validation
    bool isValidEffect(PerformanceFX effect) const override;
    bool isValidIntensity(float intensity) const override;

private:
    std::shared_ptr<IPatternSystem> patternSystem_;

    // FX state
    PerformanceFXState fxState_;
    std::atomic<bool> initialized_{false};
    std::atomic<bool> fxModeActive_{false};
    std::atomic<float> bpm_{120.0f};
    mutable std::mutex fxMutex_;

    // Audio processing
    AudioProcessCallback audioCallback_;

    // Effect names (from monolith)
    static const std::array<std::string, 16> PERFORMANCE_FX_NAMES;

    // Helper methods
    void initializeEffectState(PerformanceFX effect);
    void processLoopEffect(PerformanceFX effect, int currentStep, int& nextStep) const;
    void processAudioEffect(PerformanceFX effect, float* audioBuffer, size_t bufferSize, float intensity) const;
    void initializeShuffledStepOrder();

    // Static counters for double-time effects
    mutable int doubleTime12Counter_ = 0;
    mutable int doubleTimeShortCounter_ = 0;
    mutable int doubleTimeShorterCounter_ = 0;
    mutable int buildUpCounter_ = 0;
    mutable int sixEightIndex_ = 0;
    mutable bool scratchDirection_ = true;
    mutable int scratchSegmentStart_ = 0;
    mutable bool skipNext_ = false;
};

} // namespace FX
} // namespace GridSequencer