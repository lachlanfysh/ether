#pragma once
#include "../core/DIContainer.h"
#include "../pattern/IPatternSystem.h"
#include <set>
#include <map>
#include <vector>

namespace GridSequencer {
namespace FX {

using Core::Result;
using Pattern::StepData;

// Performance FX types (from monolith)
enum class PerformanceFX : int {
    LOOP_16 = 0,         // loops & retriggers 16th note segments
    LOOP_12,             // loops & retriggers 12th note segments
    LOOP_SHORT,          // loops & retriggers 32nd note segments
    LOOP_SHORTER,        // loops & retriggers 48th note segments
    LOOP_16_DOUBLE,      // double-time loop 16th note segments
    LOOP_12_DOUBLE,      // double-time loop 12th note segments
    LOOP_SHORT_DOUBLE,   // double-time loop 32nd note segments
    LOOP_SHORTER_DOUBLE, // double-time loop 48th note segments
    STUTTER_SWEEP,       // volume tremolo & filter sweep
    TRANCE_GATE,         // stepped gate pattern
    HALF_RATE,           // halves speed and pitch
    BUILD_UP_16_BAR,     // gradually increases tempo/pitch over 16 bars
    QUANTIZE_6_8,        // 6/8 time quantization
    RETRIGGER_PATTERN,   // random step jumps
    REVERSE,             // play sequence backwards
    SCRATCH              // ping-pong between segments
};

// Performance FX state
struct PerformanceFXState {
    // Active effects and their intensities
    std::set<PerformanceFX> activeEffects;
    std::map<PerformanceFX, float> effectIntensities;

    // Timing state for pattern manipulation
    int stepCounter = 0;
    int loopLength = 4;
    int stutterCounter = 0;
    int scratchPosition = 0;
    bool scratchDirection = true;

    // Pattern backup for reversible effects
    std::array<std::array<StepData, 16>, 17> originalPattern; // MAX_ENGINES = 17

    // Shuffled step order for RETRIGGER_PATTERN
    std::array<int, 16> shuffledStepOrder;

    // Timing synchronization
    std::chrono::steady_clock::time_point lastTrigger;
    double stepInterval = 0.125; // 8th note in seconds at 120 BPM

    bool hasActiveEffects() const {
        return !activeEffects.empty();
    }
};

// Audio buffer processing callback type
using AudioProcessCallback = std::function<void(float* audioBuffer, size_t bufferSize)>;

// Performance FX system interface - handles real-time pattern and audio effects
class IPerformanceFXSystem {
public:
    virtual ~IPerformanceFXSystem() = default;

    // System lifecycle
    virtual Result<bool> initialize() = 0;
    virtual void shutdown() = 0;
    virtual bool isInitialized() const = 0;

    // Effect management
    virtual Result<bool> activateEffect(PerformanceFX effect, float intensity = 1.0f) = 0;
    virtual Result<bool> deactivateEffect(PerformanceFX effect) = 0;
    virtual void clearAllEffects() = 0;
    virtual bool isEffectActive(PerformanceFX effect) const = 0;
    virtual float getEffectIntensity(PerformanceFX effect) const = 0;

    // Effect stacking
    virtual std::set<PerformanceFX> getActiveEffects() const = 0;
    virtual int getActiveEffectCount() const = 0;

    // Step progression with FX
    virtual int getNextStep(int currentStep) const = 0;
    virtual void updateStepCounter() = 0;

    // Audio processing
    virtual void processAudioBuffer(float* audioBuffer, size_t bufferSize) = 0;
    virtual void setAudioProcessCallback(AudioProcessCallback callback) = 0;

    // Pattern manipulation
    virtual Result<bool> bakeEffectIntoPattern(PerformanceFX effect) = 0;
    virtual Result<bool> backupCurrentPattern() = 0;
    virtual Result<bool> restoreOriginalPattern() = 0;

    // Timing control
    virtual void setBPM(float bpm) = 0;
    virtual float getBPM() const = 0;
    virtual void setStepInterval(double intervalSeconds) = 0;
    virtual double getStepInterval() const = 0;

    // Effect-specific parameters
    virtual Result<bool> setLoopLength(int length) = 0;
    virtual int getLoopLength() const = 0;
    virtual Result<bool> setStutterRate(int rate) = 0;
    virtual int getStutterRate() const = 0;

    // FX mode state
    virtual void setFXModeActive(bool active) = 0;
    virtual bool isFXModeActive() const = 0;

    // Effect information
    virtual std::string getEffectName(PerformanceFX effect) const = 0;
    virtual std::vector<std::string> getAllEffectNames() const = 0;

    // Validation
    virtual bool isValidEffect(PerformanceFX effect) const = 0;
    virtual bool isValidIntensity(float intensity) const = 0;
};

} // namespace FX
} // namespace GridSequencer