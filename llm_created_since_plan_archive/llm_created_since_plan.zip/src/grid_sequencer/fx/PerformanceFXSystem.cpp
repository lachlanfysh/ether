#include "PerformanceFXSystem.h"
#include "../utils/Constants.h"
#include <algorithm>
#include <random>
#include <cmath>

namespace GridSequencer {
namespace FX {

// Effect names from monolith
const std::array<std::string, 16> PerformanceFXSystem::PERFORMANCE_FX_NAMES = {{
    "Loop 16", "Loop 12", "Loop Short", "Loop Shorter",
    "Loop 16 2x", "Loop 12 2x", "Loop Short 2x", "Loop Shorter 2x",
    "Stutter Sweep", "Trance Gate", "Half Rate", "16 Bar Build Up",
    "6/8 Quantize", "Retrigger Pattern", "Reverse", "Scratch"
}};

PerformanceFXSystem::PerformanceFXSystem(std::shared_ptr<IPatternSystem> patternSystem)
    : patternSystem_(patternSystem) {

    LOG_INFO("PerformanceFXSystem created");

    // Initialize shuffled step order
    for (int i = 0; i < 16; ++i) {
        fxState_.shuffledStepOrder[i] = i;
    }
    initializeShuffledStepOrder();
}

PerformanceFXSystem::~PerformanceFXSystem() {
    shutdown();
    LOG_INFO("PerformanceFXSystem destroyed");
}

Result<bool> PerformanceFXSystem::initialize() {
    if (initialized_.load()) {
        return Result<bool>::success(true);
    }

    LOG_INFO("Initializing PerformanceFXSystem...");

    // Initialize FX state
    fxState_.stepCounter = 0;
    fxState_.loopLength = 4;
    fxState_.stutterCounter = 0;
    fxState_.scratchPosition = 0;
    fxState_.scratchDirection = true;
    fxState_.stepInterval = 0.125; // 8th note at 120 BPM
    fxState_.lastTrigger = std::chrono::steady_clock::now();

    // Clear all active effects
    fxState_.activeEffects.clear();
    fxState_.effectIntensities.clear();

    initialized_ = true;
    LOG_INFO("PerformanceFXSystem initialized");
    return Result<bool>::success(true);
}

void PerformanceFXSystem::shutdown() {
    if (!initialized_.load()) {
        return;
    }

    LOG_INFO("Shutting down PerformanceFXSystem...");

    // Clear all effects
    clearAllEffects();

    initialized_ = false;
    LOG_INFO("PerformanceFXSystem shut down");
}

bool PerformanceFXSystem::isInitialized() const {
    return initialized_.load();
}

// Effect management
Result<bool> PerformanceFXSystem::activateEffect(PerformanceFX effect, float intensity) {
    if (!isValidEffect(effect) || !isValidIntensity(intensity)) {
        return Result<bool>::error("Invalid effect or intensity");
    }

    std::lock_guard<std::mutex> lock(fxMutex_);

    fxState_.activeEffects.insert(effect);
    fxState_.effectIntensities[effect] = intensity;

    // Initialize effect-specific state
    initializeEffectState(effect);

    LOG_INFO("Activated performance FX: " + getEffectName(effect));
    return Result<bool>::success(true);
}

Result<bool> PerformanceFXSystem::deactivateEffect(PerformanceFX effect) {
    if (!isValidEffect(effect)) {
        return Result<bool>::error("Invalid effect");
    }

    std::lock_guard<std::mutex> lock(fxMutex_);

    fxState_.activeEffects.erase(effect);
    fxState_.effectIntensities.erase(effect);

    LOG_INFO("Deactivated performance FX: " + getEffectName(effect));
    return Result<bool>::success(true);
}

void PerformanceFXSystem::clearAllEffects() {
    std::lock_guard<std::mutex> lock(fxMutex_);

    fxState_.activeEffects.clear();
    fxState_.effectIntensities.clear();

    LOG_INFO("Cleared all performance FX");
}

bool PerformanceFXSystem::isEffectActive(PerformanceFX effect) const {
    std::lock_guard<std::mutex> lock(fxMutex_);
    return fxState_.activeEffects.find(effect) != fxState_.activeEffects.end();
}

float PerformanceFXSystem::getEffectIntensity(PerformanceFX effect) const {
    std::lock_guard<std::mutex> lock(fxMutex_);
    auto it = fxState_.effectIntensities.find(effect);
    return (it != fxState_.effectIntensities.end()) ? it->second : 0.0f;
}

// Effect stacking
std::set<PerformanceFX> PerformanceFXSystem::getActiveEffects() const {
    std::lock_guard<std::mutex> lock(fxMutex_);
    return fxState_.activeEffects;
}

int PerformanceFXSystem::getActiveEffectCount() const {
    std::lock_guard<std::mutex> lock(fxMutex_);
    return static_cast<int>(fxState_.activeEffects.size());
}

// Step progression with FX
int PerformanceFXSystem::getNextStep(int currentStep) const {
    std::lock_guard<std::mutex> lock(fxMutex_);

    if (!fxState_.hasActiveEffects()) {
        return (currentStep + 1) % 16; // Normal progression
    }

    int nextStep = (currentStep + 1) % 16;
    bool stepModified = false;

    // Apply each active effect to the step progression
    for (auto effect : fxState_.activeEffects) {
        float intensity = fxState_.effectIntensities.at(effect);
        (void)intensity; // May be unused in some effects
        int tempStep = nextStep;

        switch (effect) {
            case PerformanceFX::REVERSE:
                // Play sequence backwards
                tempStep = (nextStep - 1 + 16) % 16;
                stepModified = true;
                break;

            case PerformanceFX::LOOP_16:
                // Loop every 1 step - stay on same step
                tempStep = nextStep;
                stepModified = true;
                break;

            case PerformanceFX::LOOP_12:
                // Loop every 2 steps
                tempStep = (nextStep + 1) % 2 == 0 ? nextStep - 1 : nextStep + 1;
                stepModified = true;
                break;

            case PerformanceFX::LOOP_SHORT:
                // Loop every 4 steps
                tempStep = (nextStep + 1) % 4 == 0 ? nextStep - 3 : nextStep + 1;
                stepModified = true;
                break;

            case PerformanceFX::LOOP_SHORTER:
                // Loop every 8 steps
                tempStep = (nextStep + 1) % 8 == 0 ? nextStep - 7 : nextStep + 1;
                stepModified = true;
                break;

            case PerformanceFX::LOOP_16_DOUBLE:
                // Double-time: stay on current step for rapid triggering
                tempStep = nextStep;
                stepModified = true;
                break;

            case PerformanceFX::LOOP_12_DOUBLE:
                // Double-time: Loop every 2 steps at double BPM
                {
                    int loopStart = (nextStep / 2) * 2;
                    doubleTime12Counter_ = (doubleTime12Counter_ + 1) % 2;
                    tempStep = loopStart + doubleTime12Counter_;
                    stepModified = true;
                }
                break;

            case PerformanceFX::LOOP_SHORT_DOUBLE:
                // Double-time: Loop every 4 steps at double BPM
                {
                    int loopStart = (nextStep / 4) * 4;
                    doubleTimeShortCounter_ = (doubleTimeShortCounter_ + 1) % 4;
                    tempStep = loopStart + doubleTimeShortCounter_;
                    stepModified = true;
                }
                break;

            case PerformanceFX::LOOP_SHORTER_DOUBLE:
                // Double-time: Loop every 8 steps at double BPM
                {
                    int loopStart = (nextStep / 8) * 8;
                    doubleTimeShorterCounter_ = (doubleTimeShorterCounter_ + 1) % 8;
                    tempStep = loopStart + doubleTimeShorterCounter_;
                    stepModified = true;
                }
                break;

            case PerformanceFX::SCRATCH:
                // Scratch ping-pong: bounce between 4-step segments
                {
                    if (nextStep % 4 == 0) {
                        scratchDirection_ = !scratchDirection_;
                        scratchSegmentStart_ = nextStep;
                    }

                    if (scratchDirection_) {
                        tempStep = scratchSegmentStart_ + (nextStep % 4);
                    } else {
                        tempStep = scratchSegmentStart_ + (3 - (nextStep % 4));
                    }
                    stepModified = true;
                }
                break;

            case PerformanceFX::STUTTER_SWEEP:
                // Volume tremolo & filter sweep effect
                if (fxState_.stutterCounter % 8 == 0) {
                    tempStep = nextStep; // Stutter every 8th beat
                    stepModified = true;
                }
                break;

            case PerformanceFX::TRANCE_GATE:
                // Stepped gate that chops the sound rhythmically
                {
                    static int gatePattern[] = {1, 0, 1, 0, 1, 1, 0, 1, 0, 1, 0, 0, 1, 0, 1, 0};
                    if (!gatePattern[nextStep]) {
                        tempStep = (nextStep + 2) % 16; // Skip this step
                        stepModified = true;
                    }
                }
                break;

            case PerformanceFX::HALF_RATE:
                // Halves speed and pitch - skip every other step
                skipNext_ = !skipNext_;
                if (skipNext_) {
                    tempStep = nextStep; // Stay on current step
                    stepModified = true;
                }
                break;

            case PerformanceFX::BUILD_UP_16_BAR:
                // Gradually increases tempo/pitch over 16 bars
                buildUpCounter_++;
                if (buildUpCounter_ < 256) { // 16 bars * 16 steps
                    // Occasionally skip steps to create build-up effect
                    if (buildUpCounter_ % (17 - (buildUpCounter_ / 32)) == 0) {
                        tempStep = (nextStep + 2) % 16;
                        stepModified = true;
                    }
                } else {
                    buildUpCounter_ = 0; // Reset after 16 bars
                }
                break;

            case PerformanceFX::RETRIGGER_PATTERN:
                // Random step jumps (reduced probability when stacked)
                if (rand() % (8 * static_cast<int>(fxState_.activeEffects.size())) == 0) {
                    tempStep = rand() % 16; // Jump to random step
                    stepModified = true;
                }
                break;

            case PerformanceFX::QUANTIZE_6_8:
                // 6/8 time - skip steps to create triplet feel
                {
                    static int sixEightPattern[] = {0, 2, 4, 6, 8, 10}; // Only trigger on these steps
                    sixEightIndex_ = (sixEightIndex_ + 1) % 6;
                    tempStep = sixEightPattern[sixEightIndex_];
                    stepModified = true;
                }
                break;

            default:
                break;
        }

        // Apply the effect's result
        if (stepModified) {
            nextStep = tempStep;
        }
    }

    return nextStep;
}

void PerformanceFXSystem::updateStepCounter() {
    std::lock_guard<std::mutex> lock(fxMutex_);
    fxState_.stepCounter++;
    fxState_.stutterCounter++;
    fxState_.scratchPosition++;
}

// Audio processing
void PerformanceFXSystem::processAudioBuffer(float* audioBuffer, size_t bufferSize) {
    if (!audioBuffer || bufferSize == 0) {
        return;
    }

    std::lock_guard<std::mutex> lock(fxMutex_);

    if (!fxState_.hasActiveEffects()) {
        return;
    }

    // Apply each active audio effect
    for (auto effect : fxState_.activeEffects) {
        float intensity = fxState_.effectIntensities.at(effect) * 0.4f; // Reduced for stacking
        processAudioEffect(effect, audioBuffer, bufferSize, intensity);
    }

    // Call user callback if set
    if (audioCallback_) {
        audioCallback_(audioBuffer, bufferSize);
    }
}

void PerformanceFXSystem::setAudioProcessCallback(AudioProcessCallback callback) {
    audioCallback_ = callback;
}

// Pattern manipulation
Result<bool> PerformanceFXSystem::bakeEffectIntoPattern(PerformanceFX effect) {
    if (!isValidEffect(effect) || !patternSystem_) {
        return Result<bool>::error("Invalid effect or pattern system not available");
    }

    std::lock_guard<std::mutex> lock(fxMutex_);

    switch (effect) {
        case PerformanceFX::REVERSE:
            // Reverse all engine patterns
            for (int engine = 0; engine < MAX_ENGINES; ++engine) {
                patternSystem_->reversePattern(engine);
            }
            break;

        case PerformanceFX::RETRIGGER_PATTERN:
            // Shuffle all engine patterns
            for (int engine = 0; engine < MAX_ENGINES; ++engine) {
                patternSystem_->shufflePattern(engine);
            }
            break;

        default:
            // Most effects are timing-based and can't be baked into patterns
            LOG_WARNING("Cannot bake effect " + getEffectName(effect) + " into pattern");
            return Result<bool>::error("Effect cannot be baked into pattern");
    }

    LOG_INFO("Baked effect " + getEffectName(effect) + " into pattern");
    return Result<bool>::success(true);
}

Result<bool> PerformanceFXSystem::backupCurrentPattern() {
    if (!patternSystem_) {
        return Result<bool>::error("Pattern system not available");
    }

    std::lock_guard<std::mutex> lock(fxMutex_);

    // Backup current patterns from pattern system
    for (int engine = 0; engine < MAX_ENGINES; ++engine) {
        auto pattern = patternSystem_->exportPattern(engine);
        for (int step = 0; step < 16 && step < static_cast<int>(pattern.size()); ++step) {
            fxState_.originalPattern[engine][step] = pattern[step];
        }
    }

    LOG_INFO("Backed up current pattern");
    return Result<bool>::success(true);
}

Result<bool> PerformanceFXSystem::restoreOriginalPattern() {
    if (!patternSystem_) {
        return Result<bool>::error("Pattern system not available");
    }

    std::lock_guard<std::mutex> lock(fxMutex_);

    // Restore original patterns to pattern system
    for (int engine = 0; engine < MAX_ENGINES; ++engine) {
        std::vector<StepData> pattern;
        for (int step = 0; step < 16; ++step) {
            pattern.push_back(fxState_.originalPattern[engine][step]);
        }
        patternSystem_->importPattern(engine, pattern);
    }

    LOG_INFO("Restored original pattern");
    return Result<bool>::success(true);
}

// Timing control
void PerformanceFXSystem::setBPM(float bpm) {
    bpm_ = std::max(60.0f, std::min(200.0f, bpm));

    // Update step interval based on new BPM
    double beatDuration = 60.0 / bpm;
    setStepInterval(beatDuration / 4.0); // 16th note
}

float PerformanceFXSystem::getBPM() const {
    return bpm_.load();
}

void PerformanceFXSystem::setStepInterval(double intervalSeconds) {
    std::lock_guard<std::mutex> lock(fxMutex_);
    fxState_.stepInterval = intervalSeconds;
}

double PerformanceFXSystem::getStepInterval() const {
    std::lock_guard<std::mutex> lock(fxMutex_);
    return fxState_.stepInterval;
}

// Effect-specific parameters
Result<bool> PerformanceFXSystem::setLoopLength(int length) {
    if (length < 1 || length > 16) {
        return Result<bool>::error("Invalid loop length");
    }

    std::lock_guard<std::mutex> lock(fxMutex_);
    fxState_.loopLength = length;
    return Result<bool>::success(true);
}

int PerformanceFXSystem::getLoopLength() const {
    std::lock_guard<std::mutex> lock(fxMutex_);
    return fxState_.loopLength;
}

Result<bool> PerformanceFXSystem::setStutterRate(int rate) {
    if (rate < 1 || rate > 32) {
        return Result<bool>::error("Invalid stutter rate");
    }

    // Stutter rate affects the counter reset frequency
    // This is simplified - in a full implementation you'd have more control
    return Result<bool>::success(true);
}

int PerformanceFXSystem::getStutterRate() const {
    return 8; // Fixed rate for now
}

// FX mode state
void PerformanceFXSystem::setFXModeActive(bool active) {
    fxModeActive_ = active;
}

bool PerformanceFXSystem::isFXModeActive() const {
    return fxModeActive_.load();
}

// Effect information
std::string PerformanceFXSystem::getEffectName(PerformanceFX effect) const {
    int index = static_cast<int>(effect);
    if (index >= 0 && index < static_cast<int>(PERFORMANCE_FX_NAMES.size())) {
        return PERFORMANCE_FX_NAMES[index];
    }
    return "Unknown";
}

std::vector<std::string> PerformanceFXSystem::getAllEffectNames() const {
    std::vector<std::string> names;
    for (const auto& name : PERFORMANCE_FX_NAMES) {
        names.push_back(name);
    }
    return names;
}

// Validation
bool PerformanceFXSystem::isValidEffect(PerformanceFX effect) const {
    int index = static_cast<int>(effect);
    return index >= 0 && index < static_cast<int>(PERFORMANCE_FX_NAMES.size());
}

bool PerformanceFXSystem::isValidIntensity(float intensity) const {
    return intensity >= 0.0f && intensity <= 1.0f;
}

// Private helper methods
void PerformanceFXSystem::initializeEffectState(PerformanceFX effect) {
    switch (effect) {
        case PerformanceFX::LOOP_16:
            fxState_.loopLength = 4; // 16th note loop
            break;
        case PerformanceFX::LOOP_12:
            fxState_.loopLength = 3; // 12th note loop
            break;
        case PerformanceFX::LOOP_SHORT:
            fxState_.loopLength = 2; // 32nd note segments
            break;
        case PerformanceFX::LOOP_SHORTER:
            fxState_.loopLength = 1; // 48th note segments
            break;
        case PerformanceFX::RETRIGGER_PATTERN:
            initializeShuffledStepOrder();
            break;
        default:
            break;
    }
}

void PerformanceFXSystem::processAudioEffect(PerformanceFX effect, float* audioBuffer, size_t bufferSize, float intensity) const {
    const float PI = 3.14159265359f;

    switch (effect) {
        case PerformanceFX::STUTTER_SWEEP: {
            // Gentle volume tremolo
            for (size_t i = 0; i < bufferSize; i += 2) {
                float cycle = (fxState_.stutterCounter % 64) / 64.0f;
                float gate = (sin(cycle * PI * 2) * 0.3f + 0.7f) * intensity;
                audioBuffer[i] *= gate;
                audioBuffer[i + 1] *= gate;
            }
            break;
        }

        case PerformanceFX::TRANCE_GATE: {
            // Stepped gate with low-pass filter
            static int gatePattern[] = {1, 0, 1, 0, 1, 1, 0, 1, 0, 1, 0, 0, 1, 0, 1, 0};
            static float lpf_left = 0, lpf_right = 0;

            for (size_t i = 0; i < bufferSize; i += 2) {
                int gateIndex = (fxState_.stepCounter / 64) % 16;
                float gate = gatePattern[gateIndex] * intensity;

                // Simple low-pass filter
                float cutoff = 0.1f + gate * 0.4f;
                lpf_left += (audioBuffer[i] - lpf_left) * cutoff;
                lpf_right += (audioBuffer[i + 1] - lpf_right) * cutoff;

                audioBuffer[i] = lpf_left * gate;
                audioBuffer[i + 1] = lpf_right * gate;
            }
            break;
        }

        case PerformanceFX::HALF_RATE: {
            // Halves speed and pitch - creates choppy effect
            for (size_t i = 0; i < bufferSize; i += 2) {
                if (fxState_.scratchPosition % 2 == 0) {
                    // Keep current sample
                } else {
                    // Zero out sample for half-rate effect
                    audioBuffer[i] *= (1.0f - intensity);
                    audioBuffer[i + 1] *= (1.0f - intensity);
                }
            }
            break;
        }

        case PerformanceFX::BUILD_UP_16_BAR: {
            // Ramps up pitch and intensity over time
            float buildAmount = (buildUpCounter_ % 2048) / 2048.0f; // 16 bars worth
            float filterAmount = sin(buildUpCounter_ * 0.01f * buildAmount) * intensity;

            for (size_t i = 0; i < bufferSize; i += 2) {
                float gain = 1.0f + buildAmount * intensity * 0.5f;
                audioBuffer[i] *= gain * (1.0f + filterAmount);
                audioBuffer[i + 1] *= gain * (1.0f + filterAmount);
            }
            break;
        }

        // Loop effects don't process audio directly - they affect timing
        default:
            break;
    }
}

void PerformanceFXSystem::initializeShuffledStepOrder() {
    // Initialize with sequential order
    for (int i = 0; i < 16; ++i) {
        fxState_.shuffledStepOrder[i] = i;
    }

    // Shuffle using Fisher-Yates algorithm
    static std::random_device rd;
    static std::mt19937 g(rd());
    for (int i = 15; i > 0; --i) {
        std::uniform_int_distribution<> dis(0, i);
        int j = dis(g);
        std::swap(fxState_.shuffledStepOrder[i], fxState_.shuffledStepOrder[j]);
    }
}

} // namespace FX
} // namespace GridSequencer