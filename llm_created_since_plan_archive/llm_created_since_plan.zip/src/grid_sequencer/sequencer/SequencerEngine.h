#pragma once
#include "ISequencerEngine.h"
#include "../audio/IAudioEngine.h"
#include "../state/IStateManager.h"
#include "../parameter/IParameterSystem.h"
#include "../pattern/IPatternSystem.h"
#include "../utils/Logger.h"
#include <thread>
#include <atomic>
#include <chrono>
#include <map>
#include <queue>
#include <mutex>

namespace GridSequencer {
namespace Sequencer {

using Audio::IAudioEngine;
using State::IStateManager;
using Parameter::IParameterSystem;

// Scheduled note event for timing
struct ScheduledNote {
    int engine;
    int step;
    int note;
    float velocity;
    float duration;
    bool isNoteOn;
    std::chrono::steady_clock::time_point triggerTime;

    bool operator<(const ScheduledNote& other) const {
        return triggerTime > other.triggerTime; // Min-heap (earliest first)
    }
};

class SequencerEngine : public ISequencerEngine {
public:
    SequencerEngine(
        std::shared_ptr<IAudioEngine> audioEngine,
        std::shared_ptr<IStateManager> stateManager,
        std::shared_ptr<IParameterSystem> parameterSystem,
        std::shared_ptr<Pattern::IPatternSystem> patternSystem
    );
    virtual ~SequencerEngine();

    // Transport control
    Result<bool> play() override;
    Result<bool> stop() override;
    Result<bool> pause() override;
    TransportState getTransportState() const override;

    // Step control
    int getCurrentStep() const override;
    void setCurrentStep(int step) override;
    void advanceStep() override;
    void resetToStep(int step) override;

    // Timing configuration
    void setBPM(float bpm) override;
    float getBPM() const override;
    void setStepsPerBeat(int steps) override;
    int getStepsPerBeat() const override;
    void setPatternLength(int steps) override;
    int getPatternLength() const override;

    // Swing and timing feel
    void setSwing(float amount) override;
    float getSwing() const override;
    void enableSwing(bool enabled) override;
    bool isSwingEnabled() const override;

    // Step timing calculations
    float getStepDurationMs() const override;
    float getStepDurationMs(int step) const override;
    float getBeatDurationMs() const override;

    // Note scheduling
    void scheduleNote(int engine, int step, int note, float velocity, float duration) override;
    void scheduleNoteOff(int engine, int step, int note, float delayMs) override;
    void clearScheduledNotes(int engine) override;
    void clearAllScheduledNotes() override;

    // Callbacks
    void setStepTriggerCallback(StepTriggerCallback callback) override;
    void setNoteEventCallback(NoteEventCallback callback) override;

    // Engine management
    void enableEngine(int engine, bool enabled) override;
    bool isEngineEnabled(int engine) const override;
    void soloEngine(int engine) override;
    void unsoloEngine() override;
    int getSoloEngine() const override;

    // Pattern modes
    void setPlayAllEngines(bool playAll) override;
    bool isPlayAllEnginesEnabled() const override;

    // Sequencer lifecycle
    Result<bool> initialize() override;
    void shutdown() override;
    bool isInitialized() const override;

    // Real-time status
    bool isRunning() const override;
    float getCurrentBPM() const override;
    int getActiveVoiceCount() const override;

private:
    std::shared_ptr<IAudioEngine> audioEngine_;
    std::shared_ptr<IStateManager> stateManager_;
    std::shared_ptr<IParameterSystem> parameterSystem_;
    std::shared_ptr<Pattern::IPatternSystem> patternSystem_;

    // Sequencer state
    std::atomic<bool> initialized_{false};
    std::atomic<bool> running_{false};
    std::atomic<TransportState> transportState_{TransportState::STOPPED};

    // Timing configuration
    SequencerConfig config_;
    std::atomic<int> currentStep_{0};

    // Engine management
    std::map<int, bool> enabledEngines_;
    int soloEngine_{-1};
    bool playAllEngines_{false};

    // Threading
    std::thread sequencerThread_;
    std::atomic<bool> shouldStop_{false};

    // Note scheduling
    std::priority_queue<ScheduledNote> scheduledNotes_;
    std::mutex notesMutex_;

    // Callbacks
    StepTriggerCallback stepTriggerCallback_;
    NoteEventCallback noteEventCallback_;

    // Helper methods
    void sequencerLoop();
    void triggerCurrentStep();
    void triggerDrumStep(int engine);
    void triggerMelodicStep(int engine);
    void processScheduledNotes();
    float calculateSwingDelay(int step) const;
    bool isEngineDrum(int engine) const;
    int getEngineSlot(int engine) const;
    void scheduleNoteOffForMelodicEngine(int engine, int step, float noteOffDelayMs);

    // Performance FX integration
    int getNextStepWithFX(int currentStep) const;

    // Note triggering helpers
    void triggerDrumNote(int engine, int pad, float velocity);
    void triggerMelodicNote(int engine, int note, float velocity);
    void triggerNoteOff(int engine, int note);
};

} // namespace Sequencer
} // namespace GridSequencer