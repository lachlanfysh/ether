#pragma once
#include "../core/DIContainer.h"
#include "../core/DataStructures.h"
#include "../utils/Constants.h"
#include <functional>

namespace GridSequencer {
namespace Sequencer {

using Core::Result;

// Transport states
enum class TransportState {
    STOPPED,
    PLAYING,
    PAUSED
};

// Sequencer timing configuration
struct SequencerConfig {
    float bpm = 120.0f;
    int stepsPerBeat = 4;
    int patternLength = 16;
    bool swingEnabled = false;
    float swingAmount = 0.0f;
};

// Note event for sequencer output
struct NoteEvent {
    int engine;
    int step;
    int note;
    float velocity;
    float duration;
    bool isNoteOn;
};

// Step trigger callback type
using StepTriggerCallback = std::function<void(int engine, int step)>;
using NoteEventCallback = std::function<void(const NoteEvent& event)>;

// Sequencer engine interface - handles timing and note triggering
class ISequencerEngine {
public:
    virtual ~ISequencerEngine() = default;

    // Transport control
    virtual Result<bool> play() = 0;
    virtual Result<bool> stop() = 0;
    virtual Result<bool> pause() = 0;
    virtual TransportState getTransportState() const = 0;

    // Step control
    virtual int getCurrentStep() const = 0;
    virtual void setCurrentStep(int step) = 0;
    virtual void advanceStep() = 0;
    virtual void resetToStep(int step) = 0;

    // Timing configuration
    virtual void setBPM(float bpm) = 0;
    virtual float getBPM() const = 0;
    virtual void setStepsPerBeat(int steps) = 0;
    virtual int getStepsPerBeat() const = 0;
    virtual void setPatternLength(int steps) = 0;
    virtual int getPatternLength() const = 0;

    // Swing and timing feel
    virtual void setSwing(float amount) = 0;
    virtual float getSwing() const = 0;
    virtual void enableSwing(bool enabled) = 0;
    virtual bool isSwingEnabled() const = 0;

    // Step timing calculations
    virtual float getStepDurationMs() const = 0;
    virtual float getStepDurationMs(int step) const = 0; // With swing
    virtual float getBeatDurationMs() const = 0;

    // Note scheduling
    virtual void scheduleNote(int engine, int step, int note, float velocity, float duration) = 0;
    virtual void scheduleNoteOff(int engine, int step, int note, float delayMs) = 0;
    virtual void clearScheduledNotes(int engine) = 0;
    virtual void clearAllScheduledNotes() = 0;

    // Callbacks
    virtual void setStepTriggerCallback(StepTriggerCallback callback) = 0;
    virtual void setNoteEventCallback(NoteEventCallback callback) = 0;

    // Engine management
    virtual void enableEngine(int engine, bool enabled) = 0;
    virtual bool isEngineEnabled(int engine) const = 0;
    virtual void soloEngine(int engine) = 0;
    virtual void unsoloEngine() = 0;
    virtual int getSoloEngine() const = 0;

    // Pattern modes
    virtual void setPlayAllEngines(bool playAll) = 0;
    virtual bool isPlayAllEnginesEnabled() const = 0;

    // Sequencer lifecycle
    virtual Result<bool> initialize() = 0;
    virtual void shutdown() = 0;
    virtual bool isInitialized() const = 0;

    // Real-time status
    virtual bool isRunning() const = 0;
    virtual float getCurrentBPM() const = 0;
    virtual int getActiveVoiceCount() const = 0;
};

} // namespace Sequencer
} // namespace GridSequencer