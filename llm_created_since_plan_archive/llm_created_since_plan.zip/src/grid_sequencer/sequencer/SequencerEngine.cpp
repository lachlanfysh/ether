#include "SequencerEngine.h"
#include "../utils/Constants.h"
#include <cmath>
#include <random>

namespace GridSequencer {
namespace Sequencer {

// Drum pad to MIDI note mapping (from monolith)
static const int DRUM_PAD_NOTES[16] = {
    36, 38, 42, 46, 49, 51, 53, 56, 60, 62, 64, 67, 69, 71, 40, 70
};

SequencerEngine::SequencerEngine(
    std::shared_ptr<IAudioEngine> audioEngine,
    std::shared_ptr<IStateManager> stateManager,
    std::shared_ptr<IParameterSystem> parameterSystem,
    std::shared_ptr<Pattern::IPatternSystem> patternSystem)
    : audioEngine_(audioEngine)
    , stateManager_(stateManager)
    , parameterSystem_(parameterSystem)
    , patternSystem_(patternSystem) {

    LOG_INFO("SequencerEngine created");

    // Initialize enabled engines (all enabled by default)
    for (int i = 0; i < MAX_ENGINES; ++i) {
        enabledEngines_[i] = true;
    }
}

SequencerEngine::~SequencerEngine() {
    shutdown();
    LOG_INFO("SequencerEngine destroyed");
}

Result<bool> SequencerEngine::initialize() {
    if (initialized_.load()) {
        return Result<bool>::success(true);
    }

    LOG_INFO("Initializing SequencerEngine...");

    // Set default configuration
    config_.bpm = 120.0f;
    config_.stepsPerBeat = 4;
    config_.patternLength = 16;
    config_.swingEnabled = false;
    config_.swingAmount = 0.0f;

    currentStep_ = 0;
    transportState_ = TransportState::STOPPED;
    running_ = false;
    shouldStop_ = false;

    initialized_ = true;
    LOG_INFO("SequencerEngine initialized");
    return Result<bool>::success(true);
}

void SequencerEngine::shutdown() {
    if (!initialized_.load()) {
        return;
    }

    LOG_INFO("Shutting down SequencerEngine...");

    // Stop sequencer if running
    stop();

    // Clear scheduled notes
    clearAllScheduledNotes();

    initialized_ = false;
    LOG_INFO("SequencerEngine shut down");
}

Result<bool> SequencerEngine::play() {
    if (!initialized_.load()) {
        return Result<bool>::error("SequencerEngine not initialized");
    }

    if (transportState_.load() == TransportState::PLAYING) {
        return Result<bool>::success(true);
    }

    LOG_INFO("Starting sequencer playback");

    transportState_ = TransportState::PLAYING;
    running_ = true;
    shouldStop_ = false;
    currentStep_ = 0;

    // Start sequencer thread
    sequencerThread_ = std::thread(&SequencerEngine::sequencerLoop, this);

    return Result<bool>::success(true);
}

Result<bool> SequencerEngine::stop() {
    if (transportState_.load() == TransportState::STOPPED) {
        return Result<bool>::success(true);
    }

    LOG_INFO("Stopping sequencer playback");

    shouldStop_ = true;
    transportState_ = TransportState::STOPPED;
    running_ = false;

    // Stop all notes
    if (audioEngine_) {
        audioEngine_->allNotesOff();
    }

    // Wait for thread to finish
    if (sequencerThread_.joinable()) {
        sequencerThread_.join();
    }

    return Result<bool>::success(true);
}

Result<bool> SequencerEngine::pause() {
    if (transportState_.load() != TransportState::PLAYING) {
        return Result<bool>::error("Sequencer not playing");
    }

    transportState_ = TransportState::PAUSED;
    return Result<bool>::success(true);
}

void SequencerEngine::sequencerLoop() {
    LOG_INFO("Sequencer thread started");

    while (!shouldStop_.load()) {
        if (transportState_.load() == TransportState::PLAYING) {
            // Update current step from state manager
            int stateStep = stateManager_->getCurrentStep();
            if (stateStep != currentStep_.load()) {
                currentStep_ = stateStep;
            }

            // Trigger current step
            triggerCurrentStep();

            // Process scheduled note-offs
            processScheduledNotes();

            // Call step trigger callback
            if (stepTriggerCallback_) {
                stepTriggerCallback_(stateManager_->getCurrentEngine(), currentStep_.load());
            }

            // Advance to next step with Performance FX
            int nextStep = getNextStepWithFX(currentStep_.load());
            currentStep_ = nextStep;
            stateManager_->setCurrentStep(nextStep);

            // Calculate step duration with swing
            float stepMs = getStepDurationMs(currentStep_.load());

            // Sleep for step duration
            std::this_thread::sleep_for(std::chrono::milliseconds(static_cast<int>(stepMs)));
        } else if (transportState_.load() == TransportState::PAUSED) {
            // Just sleep when paused
            std::this_thread::sleep_for(std::chrono::milliseconds(50));
        } else {
            break; // STOPPED
        }
    }

    LOG_INFO("Sequencer thread stopped");
}

void SequencerEngine::triggerCurrentStep() {
    int currentEngine = stateManager_->getCurrentEngine();
    int step = currentStep_.load();

    if (playAllEngines_) {
        // Trigger all enabled engines
        for (int engine = 0; engine < MAX_ENGINES; ++engine) {
            if (!isEngineEnabled(engine)) continue;
            if (soloEngine_ >= 0 && engine != soloEngine_) continue;

            if (isEngineDrum(engine)) {
                triggerDrumStep(engine);
            } else {
                triggerMelodicStep(engine);
            }
        }
    } else {
        // Trigger only current engine
        if (isEngineEnabled(currentEngine) &&
            (soloEngine_ < 0 || currentEngine == soloEngine_)) {

            if (isEngineDrum(currentEngine)) {
                triggerDrumStep(currentEngine);
            } else {
                triggerMelodicStep(currentEngine);
            }
        }
    }
}

void SequencerEngine::triggerDrumStep(int engine) {
    int step = currentStep_.load();
    int slot = getEngineSlot(engine);
    if (slot < 0) return;

    // Set active instrument
    if (audioEngine_) {
        audioEngine_->setActiveInstrument(slot);
    }

    // Get drum pattern from state manager
    // This is simplified - in the full implementation you'd get the actual drum masks
    // For now, just trigger a basic pattern
    if (step % 4 == 0) { // Kick on 1s
        float velocity = 0.9f; // Would check accent latch in full implementation
        triggerDrumNote(engine, 0, velocity); // Kick drum pad
    }
    if (step % 8 == 4) { // Snare on 3s
        float velocity = 0.9f;
        triggerDrumNote(engine, 1, velocity); // Snare drum pad
    }
    if (step % 2 == 1) { // Hi-hat on off-beats
        float velocity = 0.7f;
        triggerDrumNote(engine, 2, velocity); // Hi-hat drum pad
    }
}

void SequencerEngine::triggerMelodicStep(int engine) {
    int step = currentStep_.load();
    (void)step; // Suppress unused variable warning

    // Check if this step is active in the pattern
    // This is simplified - in the full implementation you'd check enginePatterns
    bool stepActive = (step % 4 == 0); // Simple pattern for demo

    if (stepActive) {
        int slot = getEngineSlot(engine);
        if (slot < 0) return;

        // Set active instrument
        if (audioEngine_) {
            audioEngine_->setActiveInstrument(slot);
        }

        // Calculate note (simplified - would use actual pattern data)
        int baseNote = 60 + (engine * 2); // Different notes per engine
        float velocity = 0.8f;

        triggerMelodicNote(engine, baseNote, velocity);

        // Schedule note-off
        float stepMs = getStepDurationMs();
        float releaseParam = 0.5f; // Would get from parameter system
        float noteOffMs = stepMs * (0.1f + releaseParam * 0.8f);
        scheduleNoteOffForMelodicEngine(engine, step, noteOffMs);
    }
}

void SequencerEngine::triggerDrumNote(int engine, int pad, float velocity) {
    if (pad < 0 || pad >= 16) return;

    int note = DRUM_PAD_NOTES[pad];

    if (audioEngine_) {
        audioEngine_->noteOn(note, velocity, 0.0f);
    }

    // Fire note event callback
    if (noteEventCallback_) {
        NoteEvent event;
        event.engine = engine;
        event.step = currentStep_.load();
        event.note = note;
        event.velocity = velocity;
        event.duration = 0.0f; // Drums manage their own decay
        event.isNoteOn = true;
        noteEventCallback_(event);
    }
}

void SequencerEngine::triggerMelodicNote(int engine, int note, float velocity) {
    if (audioEngine_) {
        audioEngine_->noteOn(note, velocity, 0.0f);
    }

    // Fire note event callback
    if (noteEventCallback_) {
        NoteEvent event;
        event.engine = engine;
        event.step = currentStep_.load();
        event.note = note;
        event.velocity = velocity;
        event.duration = getStepDurationMs();
        event.isNoteOn = true;
        noteEventCallback_(event);
    }
}

void SequencerEngine::triggerNoteOff(int engine, int note) {
    if (audioEngine_) {
        audioEngine_->noteOff(note);
    }

    // Fire note event callback
    if (noteEventCallback_) {
        NoteEvent event;
        event.engine = engine;
        event.step = currentStep_.load();
        event.note = note;
        event.velocity = 0.0f;
        event.duration = 0.0f;
        event.isNoteOn = false;
        noteEventCallback_(event);
    }
}

void SequencerEngine::scheduleNoteOffForMelodicEngine(int engine, int step, float noteOffDelayMs) {
    (void)step; // Suppress unused parameter warning
    std::thread([this, engine, noteOffDelayMs]() {
        std::this_thread::sleep_for(std::chrono::milliseconds(static_cast<int>(noteOffDelayMs)));
        if (running_.load()) {
            // Calculate the note that was played (simplified)
            int baseNote = 60 + (engine * 2);
            triggerNoteOff(engine, baseNote);
        }
    }).detach();
}

void SequencerEngine::processScheduledNotes() {
    std::lock_guard<std::mutex> lock(notesMutex_);
    auto now = std::chrono::steady_clock::now();

    while (!scheduledNotes_.empty() && scheduledNotes_.top().triggerTime <= now) {
        const auto& note = scheduledNotes_.top();

        if (note.isNoteOn) {
            triggerMelodicNote(note.engine, note.note, note.velocity);
        } else {
            triggerNoteOff(note.engine, note.note);
        }

        scheduledNotes_.pop();
    }
}

float SequencerEngine::calculateSwingDelay(int step) const {
    if (!config_.swingEnabled || config_.swingAmount == 0.0f) {
        return 0.0f;
    }

    // Apply swing to off-beats (odd steps)
    if (step % 2 == 1) {
        float baseStepMs = getStepDurationMs();
        return baseStepMs * config_.swingAmount * 0.5f; // Max 50% swing
    }

    return 0.0f;
}

bool SequencerEngine::isEngineDrum(int engine) const {
    if (!audioEngine_) return false;

    int slot = getEngineSlot(engine);
    if (slot < 0) return false;

    auto typeResult = audioEngine_->getInstrumentEngineType(slot);
    if (typeResult.isError()) return false;

    // Assuming DRUM_KIT type exists in EngineType enum
    return typeResult.value() == 0; // Simplified check
}

int SequencerEngine::getEngineSlot(int engine) const {
    // This is simplified - in the full implementation you'd have rowToSlot mapping
    return engine < MAX_ENGINES ? engine : -1;
}

int SequencerEngine::getNextStepWithFX(int currentStep) const {
    // Simplified - would integrate with Performance FX system
    // For now, just normal progression
    return (currentStep + 1) % config_.patternLength;
}

// Implementation of interface methods

TransportState SequencerEngine::getTransportState() const {
    return transportState_.load();
}

int SequencerEngine::getCurrentStep() const {
    return currentStep_.load();
}

void SequencerEngine::setCurrentStep(int step) {
    currentStep_ = step % config_.patternLength;
    stateManager_->setCurrentStep(currentStep_.load());
}

void SequencerEngine::advanceStep() {
    int next = getNextStepWithFX(currentStep_.load());
    setCurrentStep(next);
}

void SequencerEngine::resetToStep(int step) {
    setCurrentStep(step);
}

void SequencerEngine::setBPM(float bpm) {
    config_.bpm = std::max(60.0f, std::min(200.0f, bpm));
}

float SequencerEngine::getBPM() const {
    return config_.bpm;
}

void SequencerEngine::setStepsPerBeat(int steps) {
    config_.stepsPerBeat = std::max(1, std::min(8, steps));
}

int SequencerEngine::getStepsPerBeat() const {
    return config_.stepsPerBeat;
}

void SequencerEngine::setPatternLength(int steps) {
    config_.patternLength = std::max(1, std::min(64, steps));
}

int SequencerEngine::getPatternLength() const {
    return config_.patternLength;
}

void SequencerEngine::setSwing(float amount) {
    config_.swingAmount = std::max(0.0f, std::min(1.0f, amount));
}

float SequencerEngine::getSwing() const {
    return config_.swingAmount;
}

void SequencerEngine::enableSwing(bool enabled) {
    config_.swingEnabled = enabled;
}

bool SequencerEngine::isSwingEnabled() const {
    return config_.swingEnabled;
}

float SequencerEngine::getStepDurationMs() const {
    // Base step duration: (60 seconds / BPM) / steps_per_beat * 1000ms
    return (60.0f / config_.bpm) / config_.stepsPerBeat * 1000.0f;
}

float SequencerEngine::getStepDurationMs(int step) const {
    float baseMs = getStepDurationMs();
    float swingDelay = calculateSwingDelay(step);
    return baseMs + swingDelay;
}

float SequencerEngine::getBeatDurationMs() const {
    return (60.0f / config_.bpm) * 1000.0f;
}

void SequencerEngine::scheduleNote(int engine, int step, int note, float velocity, float duration) {
    std::lock_guard<std::mutex> lock(notesMutex_);

    ScheduledNote noteOn;
    noteOn.engine = engine;
    noteOn.step = step;
    noteOn.note = note;
    noteOn.velocity = velocity;
    noteOn.duration = duration;
    noteOn.isNoteOn = true;
    noteOn.triggerTime = std::chrono::steady_clock::now();

    scheduledNotes_.push(noteOn);
}

void SequencerEngine::scheduleNoteOff(int engine, int step, int note, float delayMs) {
    std::lock_guard<std::mutex> lock(notesMutex_);

    ScheduledNote noteOff;
    noteOff.engine = engine;
    noteOff.step = step;
    noteOff.note = note;
    noteOff.velocity = 0.0f;
    noteOff.duration = 0.0f;
    noteOff.isNoteOn = false;
    noteOff.triggerTime = std::chrono::steady_clock::now() +
                         std::chrono::milliseconds(static_cast<int>(delayMs));

    scheduledNotes_.push(noteOff);
}

void SequencerEngine::clearScheduledNotes(int engine) {
    std::lock_guard<std::mutex> lock(notesMutex_);

    // This is inefficient but simple - in production you'd use a better data structure
    std::priority_queue<ScheduledNote> filtered;
    while (!scheduledNotes_.empty()) {
        auto note = scheduledNotes_.top();
        scheduledNotes_.pop();
        if (note.engine != engine) {
            filtered.push(note);
        }
    }
    scheduledNotes_ = std::move(filtered);
}

void SequencerEngine::clearAllScheduledNotes() {
    std::lock_guard<std::mutex> lock(notesMutex_);
    while (!scheduledNotes_.empty()) {
        scheduledNotes_.pop();
    }
}

void SequencerEngine::setStepTriggerCallback(StepTriggerCallback callback) {
    stepTriggerCallback_ = callback;
}

void SequencerEngine::setNoteEventCallback(NoteEventCallback callback) {
    noteEventCallback_ = callback;
}

void SequencerEngine::enableEngine(int engine, bool enabled) {
    if (engine >= 0 && engine < MAX_ENGINES) {
        enabledEngines_[engine] = enabled;
    }
}

bool SequencerEngine::isEngineEnabled(int engine) const {
    auto it = enabledEngines_.find(engine);
    return it != enabledEngines_.end() ? it->second : false;
}

void SequencerEngine::soloEngine(int engine) {
    soloEngine_ = engine;
}

void SequencerEngine::unsoloEngine() {
    soloEngine_ = -1;
}

int SequencerEngine::getSoloEngine() const {
    return soloEngine_;
}

void SequencerEngine::setPlayAllEngines(bool playAll) {
    playAllEngines_ = playAll;
}

bool SequencerEngine::isPlayAllEnginesEnabled() const {
    return playAllEngines_;
}

bool SequencerEngine::isInitialized() const {
    return initialized_.load();
}

bool SequencerEngine::isRunning() const {
    return running_.load();
}

float SequencerEngine::getCurrentBPM() const {
    return config_.bpm;
}

int SequencerEngine::getActiveVoiceCount() const {
    return audioEngine_ ? audioEngine_->getActiveVoiceCount() : 0;
}

void SequencerEngine::triggerDrumStep(int engine) {
    if (!audioEngine_ || !stateManager_ || !patternSystem_) return;

    int step = currentStep_.load();

    // Check if there's a drum pattern active for this step
    auto stepData = patternSystem_->getStep(engine, step);
    if (!stepData.active) return; // No pattern data for this step

    // Use pattern data for note and velocity
    int note = stepData.note;
    float velocity = stepData.velocity;

    // Apply accent if set
    if (stepData.hasAccent) {
        velocity = std::min(1.0f, velocity * 1.2f); // 20% louder for accents
    }

    // Set active instrument and trigger note
    audioEngine_->setActiveInstrument(engine);
    auto noteResult = audioEngine_->noteOn(note, velocity, 0.0f);

    if (noteResult.isSuccess()) {
        LOG_DEBUG("Triggered drum step: engine=" + std::to_string(engine) +
                  " step=" + std::to_string(step) +
                  " note=" + std::to_string(note) +
                  " velocity=" + std::to_string(velocity));

        // Track active note for note-off
        stateManager_->setActiveNote(engine, step, note);

        // Call note event callback if set
        if (noteEventCallback_) {
            NoteEvent event;
            event.engine = engine;
            event.step = step;
            event.note = note;
            event.velocity = velocity;
            event.isNoteOn = true;
            noteEventCallback_(event);
        }

        // Drums typically don't need explicit note-off, but for consistency...
        float stepMs = getStepDurationMs();
        float noteOffMs = stepMs * 0.9f; // Drums ring for most of the step
        scheduleNoteOff(engine, step, note, noteOffMs);
    }
}

void SequencerEngine::triggerMelodicStep(int engine) {
    if (!audioEngine_ || !stateManager_ || !patternSystem_) return;

    int step = currentStep_.load();

    // Check if there's a melodic pattern active for this step
    auto stepData = patternSystem_->getStep(engine, step);
    if (!stepData.active) return; // No pattern data for this step

    // Use pattern data for note and velocity
    int note = stepData.note;
    float velocity = stepData.velocity;

    // Apply accent if set
    if (stepData.hasAccent) {
        velocity = std::min(1.0f, velocity * 1.3f); // 30% louder for accents
    }

    // Set active instrument and trigger note
    audioEngine_->setActiveInstrument(engine);
    auto noteResult = audioEngine_->noteOn(note, velocity, 0.0f);

    if (noteResult.isSuccess()) {
        LOG_DEBUG("Triggered melodic step: engine=" + std::to_string(engine) +
                  " step=" + std::to_string(step) +
                  " note=" + std::to_string(note) +
                  " velocity=" + std::to_string(velocity));

        // Track active note for note-off
        stateManager_->setActiveNote(engine, step, note);

        // Call note event callback if set
        if (noteEventCallback_) {
            NoteEvent event;
            event.engine = engine;
            event.step = step;
            event.note = note;
            event.velocity = velocity;
            event.isNoteOn = true;
            noteEventCallback_(event);
        }

        // Calculate note-off timing like original: stepMs * (0.1f + releaseParam * 0.8f)
        float stepMs = getStepDurationMs();

        // Get release parameter from parameter system (default to 0.3f if not available)
        float releaseParam = 0.3f;
        if (parameterSystem_) {
            auto releaseResult = parameterSystem_->getParameter(engine, ParameterID::RELEASE);
            if (releaseResult.isSuccess()) {
                releaseParam = releaseResult.value();
            }
        }

        // Original timing calculation from grid_sequencer_advanced
        float noteOffMs = stepMs * (0.1f + releaseParam * 0.8f);
        scheduleNoteOff(engine, step, note, noteOffMs);
    }
}

} // namespace Sequencer
} // namespace GridSequencer