#include "ModularGridSequencer.h"
#include "utils/Logger.h"
#include <iostream>
#include <thread>
#include <chrono>

namespace GridSequencer {

ModularGridSequencer::ModularGridSequencer() {
    LOG_INFO("ModularGridSequencer created");
}

ModularGridSequencer::~ModularGridSequencer() {
    shutdown();
    LOG_INFO("ModularGridSequencer destroyed");
}

Core::Result<bool> ModularGridSequencer::initialize() {
    if (initialized_) {
        return Core::Result<bool>::success(true);
    }

    LOG_INFO("Initializing ModularGridSequencer...");

    try {
        // Phase 1 & 2: Initialize core application
        app_ = std::make_unique<Core::Application>();
        auto appResult = app_->initialize();
        if (appResult.isError()) {
            return Core::Result<bool>::error("Failed to initialize core application: " + appResult.error());
        }

        // Get core components from DI container
        auto& container = app_->getContainer();
        auto stateManager = container.resolve<State::IStateManager>();
        auto parameterSystem = container.resolve<Parameter::IParameterSystem>();
        auto audioEngine = container.resolve<Audio::IAudioEngine>();

        if (!stateManager || !parameterSystem || !audioEngine) {
            return Core::Result<bool>::error("Failed to resolve core components from DI container");
        }

        // Phase 3: Initialize Input/Output Systems
        gridController_ = std::make_shared<Grid::MonomeGridController>(stateManager);
        inputSystem_ = std::make_shared<Input::InputSystem>(stateManager);
        uiSystem_ = std::make_shared<UI::TerminalUISystem>(stateManager, parameterSystem, audioEngine);

        gridController_->setGridPrefix("/modular_sequencer");
        gridController_->setPort(7004);

        auto inputResult = inputSystem_->initialize();
        if (inputResult.isError()) {
            return Core::Result<bool>::error("Failed to initialize input system: " + inputResult.error());
        }

        auto uiResult = uiSystem_->initialize();
        if (uiResult.isError()) {
            return Core::Result<bool>::error("Failed to initialize UI system: " + uiResult.error());
        }

        // Phase 4: Initialize Sequencer Logic Systems
        patternSystem_ = std::make_shared<Pattern::PatternSystem>(stateManager);
        sequencerEngine_ = std::make_shared<Sequencer::SequencerEngine>(audioEngine, stateManager, parameterSystem, patternSystem_);
        fxSystem_ = std::make_shared<FX::PerformanceFXSystem>(patternSystem_);

        auto patternResult = patternSystem_->initialize();
        if (patternResult.isError()) {
            return Core::Result<bool>::error("Failed to initialize pattern system: " + patternResult.error());
        }

        auto sequencerResult = sequencerEngine_->initialize();
        if (sequencerResult.isError()) {
            return Core::Result<bool>::error("Failed to initialize sequencer engine: " + sequencerResult.error());
        }

        auto fxResult = fxSystem_->initialize();
        if (fxResult.isError()) {
            return Core::Result<bool>::error("Failed to initialize FX system: " + fxResult.error());
        }

        // Phase 5: Setup integration
        setupCallbacks();
        setupDefaultPatterns();
        setupUI();

        initialized_ = true;
        LOG_INFO("ModularGridSequencer initialized successfully");
        return Core::Result<bool>::success(true);

    } catch (const std::exception& e) {
        return Core::Result<bool>::error("Exception during initialization: " + std::string(e.what()));
    }
}

void ModularGridSequencer::shutdown() {
    if (!initialized_) {
        return;
    }

    LOG_INFO("Shutting down ModularGridSequencer...");

    running_ = false;

    // Shutdown in reverse order
    if (fxSystem_) fxSystem_->shutdown();
    if (sequencerEngine_) sequencerEngine_->shutdown();
    if (patternSystem_) patternSystem_->shutdown();
    if (uiSystem_) uiSystem_->shutdown();
    if (inputSystem_) inputSystem_->shutdown();
    if (app_) app_->shutdown();

    initialized_ = false;
    LOG_INFO("ModularGridSequencer shut down");
}

bool ModularGridSequencer::isInitialized() const {
    return initialized_;
}

void ModularGridSequencer::run() {
    if (!initialized_) {
        LOG_ERROR("Cannot run - not initialized");
        return;
    }

    LOG_INFO("Starting ModularGridSequencer main loop");
    running_ = true;

    // Start sequencer
    sequencerEngine_->setBPM(120.0f);
    sequencerEngine_->play();

    // Main loop
    while (running_) {
        // Update UI
        uiSystem_->render();

        // Process any input events
        inputSystem_->processInput();

        // Update performance FX timing
        fxSystem_->updateStepCounter();

        // Sleep to avoid busy waiting
        std::this_thread::sleep_for(std::chrono::milliseconds(50));
    }

    // Stop sequencer
    sequencerEngine_->stop();
    LOG_INFO("ModularGridSequencer main loop ended");
}

// Core component access
std::shared_ptr<State::IStateManager> ModularGridSequencer::getStateManager() const {
    if (!app_) return nullptr;
    return app_->getContainer().resolve<State::IStateManager>();
}

std::shared_ptr<Parameter::IParameterSystem> ModularGridSequencer::getParameterSystem() const {
    if (!app_) return nullptr;
    return app_->getContainer().resolve<Parameter::IParameterSystem>();
}

std::shared_ptr<Audio::IAudioEngine> ModularGridSequencer::getAudioEngine() const {
    if (!app_) return nullptr;
    return app_->getContainer().resolve<Audio::IAudioEngine>();
}

void ModularGridSequencer::setupCallbacks() {
    LOG_DEBUG("Setting up callbacks");

    // Grid controller callbacks
    gridController_->setKeyHandler([this](int x, int y, int state) {
        LOG_DEBUG("Grid key: (" + std::to_string(x) + "," + std::to_string(y) + ") state=" + std::to_string(state));

        // Basic pattern editing
        if (state == 1 && x < 4 && y < 4) {
            int step = y * 4 + x;
            auto currentStep = patternSystem_->getStep(0, step);

            if (currentStep.active) {
                patternSystem_->clearStep(0, step);
            } else {
                Pattern::StepData newStep;
                newStep.active = true;
                newStep.note = 60 + x * 2 + y;
                newStep.velocity = 0.8f;
                patternSystem_->setStep(0, step, newStep);
            }
        }

        // FX control
        if (state == 1 && x >= 12 && y < 4) {
            auto effect = static_cast<FX::PerformanceFX>(y * 4 + (x - 12));
            if (fxSystem_->isEffectActive(effect)) {
                fxSystem_->deactivateEffect(effect);
            } else {
                fxSystem_->activateEffect(effect, 0.7f);
            }
        }
    });

    // Sequencer callbacks
    sequencerEngine_->setStepTriggerCallback([this](int engine, int step) {
        auto stateManager = getStateManager();
        if (stateManager) {
            stateManager->setCurrentStep(step);
        }
    });

    sequencerEngine_->setNoteEventCallback([this](const Sequencer::NoteEvent& event) {
        if (event.isNoteOn) {
            LOG_DEBUG("Note ON: engine=" + std::to_string(event.engine) +
                     " note=" + std::to_string(event.note) +
                     " vel=" + std::to_string(event.velocity));
        }
    });

    // Input system callbacks
    inputSystem_->setEventHandler([this](const Input::InputEvent& event) {
        auto parameterSystem = getParameterSystem();
        if (!parameterSystem) return;

        // Encoder control for parameters
        if (event.type == Input::InputType::ENCODER_TURN) {
            ParameterID paramId = static_cast<ParameterID>(event.encoderId);
            auto currentResult = parameterSystem->getParameter(0, paramId);
            float currentValue = currentResult.isSuccess() ? currentResult.value() : 0.0f;
            float newValue = std::max(0.0f, std::min(1.0f, currentValue + event.delta * 0.05f));
            parameterSystem->setParameter(0, paramId, newValue);
        }

        // Button control for transport
        if (event.type == Input::InputType::ENCODER_BUTTON && event.state == 1) {
            if (event.encoderId == 0) { // Play/Stop
                if (sequencerEngine_->getTransportState() == Sequencer::TransportState::PLAYING) {
                    sequencerEngine_->stop();
                } else {
                    sequencerEngine_->play();
                }
            }
        }
    });
}

void ModularGridSequencer::setupDefaultPatterns() {
    LOG_DEBUG("Setting up default patterns");

    // Create a basic drum pattern
    patternSystem_->setDrumStep(0, 0, true);   // Kick
    patternSystem_->setDrumStep(0, 4, true);
    patternSystem_->setDrumStep(0, 8, true);
    patternSystem_->setDrumStep(0, 12, true);

    patternSystem_->setDrumStep(1, 4, true);   // Snare
    patternSystem_->setDrumStep(1, 12, true);

    for (int step = 2; step < 16; step += 2) { // Hi-hat
        patternSystem_->setDrumStep(2, step, true);
    }

    // Create melodic patterns for first few engines
    for (int engine = 0; engine < 3; ++engine) {
        for (int step = 0; step < 16; step += (4 - engine)) {
            Pattern::StepData stepData;
            stepData.active = true;
            stepData.note = 60 + engine * 5 + (step % 4);
            stepData.velocity = 0.6f + engine * 0.1f;
            stepData.hasAccent = (step % 8 == 0);
            patternSystem_->setStep(engine, step, stepData);
        }
    }

    // Save default pattern
    patternSystem_->savePattern(0, 0);
}

void ModularGridSequencer::setupUI() {
    LOG_DEBUG("Setting up UI");

    uiSystem_->setDisplayMode(UI::DisplayMode::MAIN_SEQUENCER);
    uiSystem_->clear();
    uiSystem_->printLine("=== Modular Grid Sequencer ===", UI::Color::BRIGHT_CYAN);
    uiSystem_->printLine("Complete modular architecture running!", UI::Color::BRIGHT_GREEN);
    uiSystem_->printLine("", UI::Color::WHITE);
    uiSystem_->printLine("Controls:", UI::Color::YELLOW);
    uiSystem_->printLine("  Grid 0-15: Edit pattern steps", UI::Color::WHITE);
    uiSystem_->printLine("  Grid 12-15: Performance FX", UI::Color::WHITE);
    uiSystem_->printLine("  Encoders: Adjust parameters", UI::Color::WHITE);
    uiSystem_->printLine("  Button 0: Play/Stop", UI::Color::WHITE);
}

} // namespace GridSequencer