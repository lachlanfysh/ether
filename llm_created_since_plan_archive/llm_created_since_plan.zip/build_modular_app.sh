#!/bin/bash
set -e

echo "=== Building Modular Grid Sequencer Application ==="
echo ""

# Build configuration
CXXFLAGS="-std=c++17 -O2 -Wall -Wextra -Wconversion -Wimplicit-fallthrough -Wswitch-enum"
ENGINE_OBJS="src/engines/*.o src/synthesis/SynthEngine_minimal.o"
BRIDGE_OBJ="harmonized_13_engines_bridge.o"

echo "🔧 Build Configuration:"
echo "  C++ Standard: C++17"
echo "  Optimization: -O2"
echo "  Libraries: PortAudio, LibLO, Pthread"
echo "  Bridge: $BRIDGE_OBJ"
echo ""

# Check for required files
if [ ! -f "$BRIDGE_OBJ" ]; then
    echo "❌ Bridge object not found: $BRIDGE_OBJ"
    echo "   Run 'make' first to build engine objects"
    exit 1
fi

# Source files for the complete modular application
APP_SOURCES=(
    "modular_grid_sequencer_app.cpp"
    "src/grid_sequencer/ModularGridSequencer.cpp"
    "src/grid_sequencer/core/Application.cpp"
    "src/grid_sequencer/state/StateManager.cpp"
    "src/grid_sequencer/parameter/ParameterSystem.cpp"
    "src/grid_sequencer/audio/EtherSynthAudioEngine.cpp"
    "src/grid_sequencer/grid/MonomeGridController.cpp"
    "src/grid_sequencer/input/InputSystem.cpp"
    "src/grid_sequencer/ui/TerminalUISystem.cpp"
    "src/grid_sequencer/sequencer/SequencerEngine.cpp"
    "src/grid_sequencer/pattern/PatternSystem.cpp"
    "src/grid_sequencer/fx/PerformanceFXSystem.cpp"
)

echo "🏗️  Building Modular Grid Sequencer Application..."
echo "   Target: modular_grid_sequencer"
echo "   Sources: ${#APP_SOURCES[@]} source files"
echo ""

# Build the complete application
g++ $CXXFLAGS \
    -I/opt/homebrew/include \
    -Isrc -Isrc/engines -Isrc/audio -Isrc/hardware -Isrc/data \
    -o modular_grid_sequencer \
    "${APP_SOURCES[@]}" \
    $ENGINE_OBJS \
    $BRIDGE_OBJ \
    -L/opt/homebrew/lib \
    -lportaudio -pthread -llo

if [ $? -eq 0 ]; then
    echo "✅ Modular Grid Sequencer Application built successfully!"
    echo ""
    echo "📱 Application Features:"
    echo "  • Interactive real-time control"
    echo "  • 15 synthesis engines (MacroVA, FM, Wavetable, etc.)"
    echo "  • Pattern sequencing with 64 pattern slots"
    echo "  • Performance FX (Stutter, Reverse, Quantize, etc.)"
    echo "  • Live parameter control"
    echo "  • BPM and transport control"
    echo "  • Clean modular architecture"
    echo ""
    echo "🚀 Run with: ./modular_grid_sequencer"
    echo "   Press 'h' for help once running"
    echo "   Press 'q' to quit"
    echo ""
    echo "🎹 Ready to make music with your modular synthesizer!"
else
    echo "❌ Build failed"
    exit 1
fi